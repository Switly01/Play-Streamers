# Play Connect — AMO mağaza metinleri

## Kısa açıklama

Donate platformlarını Play Streamers hesabına bağlar ve doğrulanmış bağış
olaylarını kişisel yayıncı paneline aktarır.

## Tam açıklama

Play Connect, yayıncıların destek platformlarındaki bağış olaylarını tek bir Play
Streamers panelinde takip etmesini sağlar.

- Desteklenen platformlarda doğrudan API bağlantısı kullanır.
- Sunucu bildirimi sunan platformlarda sekme gerektirmeyen bağlantıyı kullanır.
- OBS / Alert Box bağlantılarını Firefox'un arka plan sayfasında görünmeden
  dinleyebilir.
- Donate gönderen adı, mesajı, tutarı, para birimi, platformu ve zamanı Play
  Streamers hesabındaki yayıncı paneline gönderir.
- Platform şifrelerini Play Streamers sunucusuna göndermez.
- Bağlantı kullanıcı tarafından her zaman kaldırılabilir.

Bu eklenti ücretsizdir. Eklentinin kendisi ödeme almaz, satış yapmaz ve Play
Streamers'ın gelecekte sunabileceği site içi aboneliği çalıştırmak için gerekli
değildir.

## Destek

https://pstreamers.com

## Gizlilik politikası

https://pstreamers.com/privacy.html
