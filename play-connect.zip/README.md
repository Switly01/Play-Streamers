# Play Connect

Chrome Manifest V3 eklentisi; API, sunucu bildirimi veya giriş sırasında
öğrenilen sekmesiz arka plan bağlantısıyla donate hareketlerini Play Streamers
hesabına bağlar.

## Desteklenen platformlar ve otomatik bağlantı seçimi

Ana ekranda:

- ByNoGame
- Klasgame
- Streamlabs
- StreamElements

“Diğerleri” bölümünde:

- Pindirim
- GameSatış
- Oyunfor
- İtemSatış
- Oyuneks
- Hesap.com.tr
- Dijipin
- EPİN
- İnovapin
- Ko-fi
- Buy Me a Coffee
- Patreon
- Fourthwall
- TipeeeStream
- DonationAlerts
- Pally.gg

Katalog toplam 33 platform içerir. Play Connect her platformu aynı kırılgan
sayfa okuyucusundan geçirmez. Uygun olanlarda doğrudan API, platformun desteklediği
durumlarda kişisel sunucu bildirim adresi, diğerlerinde sekmesiz arka plan isteği
ve geçici giriş sırasında gerçek JSON veri akışının otomatik öğrenilmesi kullanılır. Birincil yöntem çalışmazsa yalnızca o platform için
tanımlı güvenli yedek yöntem devreye alınabilir.

## Çalışma biçimi

- Her platformdaki birincil adım **Platforma giriş yap** düğmesidir. Giriş,
  platformun kendi sayfasında tamamlanır; eklenti kullanıcıdan platform
  parolasını istemez.
- Streamlabs resmî donation API'sini, StreamElements resmî `channel.tips`
  WebSocket akışını, TipeeeStream resmî Events API'sini ve DonationAlerts resmî
  Donations API'sini destekler. Pally.gg destek olayları platformun canlı
  WebSocket akışından alınır. Bu sağlayıcıların erişim anahtarları yerel
  Chrome profilinde kalır.
- İtemSatış, Ko-fi, Buy Me a Coffee, Patreon, Fourthwall, PayPal, Gumroad,
  GitHub Sponsors, Givebutter ve Donorbox için Play Streamers hesabından kişisel
  ve iptal edilebilir bir bildirim adresi oluşturulabilir. Adres platforma bir kez
  eklenince olaylar Chrome veya platform sekmesi açık olmasa da doğrudan Worker'a
  gelir. Bu adres bir parola gibi korunmalı ve herkese açık paylaşılmamalıdır.
- Sunucu bildirim bağlantısı etkin olan platform eklentide otomatik olarak
  `Sunucu bağlantısı aktif` görünür ve çift donate oluşmaması için aynı
  platformun yerel sayfa taraması durdurulur.
- ByNoGame oturumu algılandığında güncel oturumlu donate veri akışı kullanılır.
  `opId` ve `orderRowId` gerçek olay kimliği olarak okunur. ByNoGame oturum
  anahtarı yalnızca yerel Chrome profilinde tutulur ve Play Streamers
  sunucusuna gönderilmez.
- Herkese açık platform ana sayfaları ve tanıtım kartları izleme kaynağı
  değildir. Play Connect yalnız doğrulanmış JSON/API akışını kullanır; ByNoGame
  için doğrudan oturumlu incoming akışını okur. Böylece gönderilen bağışlar ve eski
  örnek kartlar kuyruğu ve sunucu hız sınırını doldurmaz.
- ByNoGame'ın sayfa kodundan görünmeyen oturum çerezi Chrome'un `cookies`
  izniyle yalnız yerelde doğrulanır. Çerez veya oturum anahtarı Play Streamers
  API'sine gönderilmez; API'ye yalnız normalize edilmiş donate olayı gider.
- API sunmayan platformlarda giriş yalnız kurulum sırasında geçici pencerede
  yapılır. Eklenti güvenli veri isteğini öğrenip arka planda doğruladığında bu
  pencereyi kapatır. Platform otomatik isteği engellerse kalıcı veya görünmeyen
  bir uzak sekme açılmaz; kullanıcıya yeniden giriş/destek durumu gösterilir.
- Listedeki bütün platformlarda sayfanın JSON yanıtları, `fetch`, XHR,
  WebSocket ve Server-Sent Events izlenir. Görünür sayfa kartları taranmaz.
  Yalnızca olay kimliği, bağışçı, tutar, para birimi, mesaj ve zaman alanları
  ayrılır; platform yanıtının geri kalanı Play Streamers sunucusuna taşınmaz.
- Platformun verdiği işlem kimliği donate kimliği olarak kullanılır. Platform
  kimlik vermiyorsa aynı taramadaki ayrı satırlara birbirinden farklı yerel olay
  kimliği atanır. Yalnız sunucu tarafından onaylanmış aynı kimlik tekrar
  gönderilmez; daha önce görülmüş fakat hiç kuyruğa alınmamış bir kayıt sessizce
  "eski" sayılmaz.
- Diğer platformlarda giriş tamamlanınca eklenti gerçek donate JSON isteğini
  otomatik öğrenir ve Chrome arka planında doğrular. Elle adres, CSS seçici veya
  satır eşleştirme alanı bulunmaz.
- Giriş penceresi yalnız kullanıcı **Platforma giriş yap** düğmesine bastığında
  açılır. Play Connect güvenli GET veri adresini ve gerekiyorsa yerel Bearer
  oturum anahtarını öğrenir, aynı isteği eklenti arka planında doğrular ve
  başarılı olduğunda geçici giriş sekmesini otomatik kapatır. Bundan sonra
  platform sayfasının açık kalması gerekmez.
- Platform oturumu algılandıktan sonra platforma özel çıkış düğmesi görünür.
  Bu düğme yalnızca kullanıcının isteğiyle ilgili platformun çıkış akışını açar.
  Platformda oturum kapandığında durum yeniden kontrol edilir, bağlantı durumu
  kırmızıya döner ve **Platforma giriş yap** düğmesi tekrar gösterilir.
- Yakalanan olay önce kalıcı yerel kuyruğa girer. Olay yalnız Play Streamers
  sunucusu açık bir teslimat onayı verdiğinde kuyruktan çıkar ve gönderilmiş
  olay defterine yazılır. Geçici hata olursa artan aralıklarla yeniden denenir.
- Sunucuda aynı kimlikle zaten bulunan olay da teslim edilmiş kabul edilip
  kuyruktan çıkarılır; fakat ikinci kez Dashboard toplamına veya onaylı olay
  sayısına eklenmez.
- Eşleştirme kodu sunucuda Play Streamers kullanıcı kimliğine bağlanır. Bu
  koddan alınan cihaz anahtarıyla gönderilen donate, yalnız eşleşen hesabın D1
  kayıtlarına ve o hesabın Dashboard Donate kartına gider.
- Platform parolaları, çerezleri, işlem geçmişi adresleri ve API anahtarları
  Play Streamers sunucusuna gönderilmez. Sunucuya yalnızca normalize edilmiş
  donate olayı gönderilir.
- Bazı sağlayıcılar otomatik istekleri engelleyebilir veya sayfa yapısını
  değiştirebilir. Böyle bir durumda gelişmiş CSS alan eşleştirme ayarları
  kullanılabilir; gerçek hesap olmadan bütün sağlayıcı akışları doğrulanmış
  kabul edilmez.

## Chrome'a kurma

1. ZIP dosyasını ayrı bir klasöre çıkar.
2. Chrome'da `chrome://extensions/` adresini aç.
3. Sağ üstten **Geliştirici modu** seçeneğini aç.
4. **Paketlenmemiş öğe yükle** düğmesine bas.
5. İçinde `manifest.json` bulunan `play-connect` klasörünü seç.
6. Play Streamers sitesinde **Hesabım → Bağlantılar** bölümünden eşleştirme kodu
   oluştur ve eklentinin ayarlar ekranına gir.

## Güvenlik

- 16 karakterli eşleştirme kodu 10 dakika geçerli ve tek kullanımlıktır.
- Sunucu cihaz anahtarının yalnızca SHA-256 özetini saklar.
- Eklentideki cihaz anahtarı `chrome.storage.local` içinde tutulur ve senkronize
  edilmez.
- Her sağlayıcı yalnızca manifestte izin verilen kendi alan adına erişebilir.
- API ve doğrulanmış sekmesiz arka plan bağlantıları Chrome açıkken sayfadan
  bağımsız çalışır. Platform otomatik isteği, çerez kullanımını veya uzantı
  erişimini engelliyorsa Play Connect görünmeyen uzak sekme açmaz; bağlantıyı
  yeniden giriş gerekli ya da sekmesiz desteklenmiyor olarak işaretler.
