# Play Connect

Chrome Manifest V3 eklentisi, yayıncının Play Connect'e ayrılmış özel platform
oturumundaki donate hareketlerini Play Streamers hesabına bağlar.

## Desteklenen platformlar ve otomatik bağlantı seçimi

Ana ekranda:

- ByNoGame
- Klasgame
- Streamlabs
- StreamElements

“Diğerleri” bölümünde:

- Pindirim
- GameSatış
- Oyunfor
- İtemSatış
- Oyuneks
- Hesap.com.tr
- Dijipin
- EPİN
- İnovapin
- Ko-fi
- Buy Me a Coffee
- Patreon
- Fourthwall
- TipeeeStream
- DonationAlerts
- Pally.gg

Katalog toplam 33 platform içerir. Play Connect her platformu aynı kırılgan
sayfa okuyucusundan geçirmez. Uygun olanlarda doğrudan API, platformun desteklediği
durumlarda kişisel sunucu bildirim adresi, diğerlerinde ayrı yönetilen oturum ve
sayfa algılama kullanılır. Birincil yöntem çalışmazsa yalnızca o platform için
tanımlı güvenli yedek yöntem devreye alınabilir.

## Çalışma biçimi

- Her platformdaki birincil adım **Platforma giriş yap** düğmesidir. Giriş,
  platformun kendi sayfasında tamamlanır; eklenti kullanıcıdan platform
  parolasını istemez.
- Streamlabs resmî donation API'sini, StreamElements resmî `channel.tips`
  WebSocket akışını, TipeeeStream resmî Events API'sini ve DonationAlerts resmî
  Donations API'sini destekler. Pally.gg destek olayları platformun canlı
  WebSocket akışından alınır. Bu sağlayıcıların erişim anahtarları yerel
  Chrome profilinde kalır.
- İtemSatış, Ko-fi, Buy Me a Coffee, Patreon, Fourthwall, PayPal, Gumroad,
  GitHub Sponsors, Givebutter ve Donorbox için Play Streamers hesabından kişisel
  ve iptal edilebilir bir bildirim adresi oluşturulabilir. Adres platforma bir kez
  eklenince olaylar Chrome veya platform sekmesi açık olmasa da doğrudan Worker'a
  gelir. Bu adres bir parola gibi korunmalı ve herkese açık paylaşılmamalıdır.
- Sunucu bildirim bağlantısı etkin olan platform eklentide otomatik olarak
  `Sunucu bağlantısı aktif` görünür ve çift donate oluşmaması için aynı
  platformun yerel sayfa taraması durdurulur.
- ByNoGame oturumu algılandığında güncel oturumlu donate veri akışı kullanılır.
  `opId` ve `orderRowId` gerçek olay kimliği olarak okunur. ByNoGame oturum
  anahtarı yalnızca yerel Chrome profilinde tutulur ve Play Streamers
  sunucusuna gönderilmez.
- ByNoGame'ın sayfa kodundan görünmeyen oturum çerezi Chrome'un `cookies`
  izniyle yalnız yerelde doğrulanır. Çerez veya oturum anahtarı Play Streamers
  API'sine gönderilmez; API'ye yalnız normalize edilmiş donate olayı gider.
- API sunmayan platformlar normal Chrome oturumundan ayrı bir Play Connect
  gizli penceresinde açılır. Bu pencerenin çerez deposu normal Chrome
  oturumuyla karışmaz. Chrome uzantıları kendi içine ikinci bir Chromium motoru
  gömemediği için güvenli uzantı karşılığı bu yönetilen ayrı penceredir.
- Listedeki bütün platformlarda sayfanın JSON yanıtları, `fetch`, XHR,
  WebSocket, Server-Sent Events ve görünür donate satırları birlikte izlenir.
  Yalnızca olay kimliği, bağışçı, tutar, para birimi, mesaj ve zaman alanları
  ayrılır; platform yanıtının geri kalanı Play Streamers sunucusuna taşınmaz.
- Platformun verdiği işlem kimliği donate kimliği olarak kullanılır. Platform
  kimlik vermiyorsa aynı taramadaki ayrı satırlara birbirinden farklı yerel olay
  kimliği atanır. Yalnız sunucu tarafından onaylanmış aynı kimlik tekrar
  gönderilmez; daha önce görülmüş fakat hiç kuyruğa alınmamış bir kayıt sessizce
  "eski" sayılmaz.
- Diğer platformlarda giriş tamamlanınca eklenti aynı alan adındaki donate,
  ödeme, işlem, gelir veya destekçi geçmişi bağlantısını otomatik bulur ve
  izleme sekmesine geçer. Gelişmiş bağlantı ve sayfa algılama ayarları otomatik
  hazırlanır; elle alan eşleştirme yalnızca site yapısı değiştiğinde yedektir.
- Giriş penceresi yalnız kullanıcı **Özel oturumda giriş yap** düğmesine
  bastığında açılır. Giriş tamamlandıktan sonra Play Connect aynı özel pencereyi
  yönetir; gerçek zamanlı akış yoksa sayfayı 30 saniyelik güvenli yedek aralıkla
  yeniler. API sunmayan platformların canlı izlenmesi için bu pencere açık veya
  simge durumuna küçültülmüş kalmalıdır.
- Platform oturumu algılandıktan sonra platforma özel çıkış düğmesi görünür.
  Bu düğme yalnızca kullanıcının isteğiyle ilgili platformun çıkış akışını açar.
  Platformda oturum kapandığında durum yeniden kontrol edilir, bağlantı durumu
  kırmızıya döner ve **Platforma giriş yap** düğmesi tekrar gösterilir.
- Yakalanan olay önce kalıcı yerel kuyruğa girer. Olay yalnız Play Streamers
  sunucusu açık bir teslimat onayı verdiğinde kuyruktan çıkar ve gönderilmiş
  olay defterine yazılır. Geçici hata olursa artan aralıklarla yeniden denenir.
- Eşleştirme kodu sunucuda Play Streamers kullanıcı kimliğine bağlanır. Bu
  koddan alınan cihaz anahtarıyla gönderilen donate, yalnız eşleşen hesabın D1
  kayıtlarına ve o hesabın Dashboard Donate kartına gider.
- Platform parolaları, çerezleri, işlem geçmişi adresleri ve API anahtarları
  Play Streamers sunucusuna gönderilmez. Sunucuya yalnızca normalize edilmiş
  donate olayı gönderilir.
- Bazı sağlayıcılar otomatik istekleri engelleyebilir veya sayfa yapısını
  değiştirebilir. Böyle bir durumda gelişmiş CSS alan eşleştirme ayarları
  kullanılabilir; gerçek hesap olmadan bütün sağlayıcı akışları doğrulanmış
  kabul edilmez.

## Chrome'a kurma

1. ZIP dosyasını ayrı bir klasöre çıkar.
2. Chrome'da `chrome://extensions/` adresini aç.
3. Sağ üstten **Geliştirici modu** seçeneğini aç.
4. **Paketlenmemiş öğe yükle** düğmesine bas.
5. İçinde `manifest.json` bulunan `play-connect` klasörünü seç.
6. Eklenti ayrıntılarında **Gizli modda izin ver** seçeneğini bir kez aç. Bu
   izin ayrı platform oturumu için zorunludur. Play Connect ilk açılışta doğru
   ayar sayfasını ve tek adımlık yönlendirmeyi otomatik gösterir; Chrome güvenlik
   anahtarının son tıklamasını yalnız kullanıcıya bırakır.
7. Play Streamers sitesinde **Hesabım → Bağlantılar** bölümünden eşleştirme kodu
   oluştur ve eklentinin ayarlar ekranına gir.

## Güvenlik

- 16 karakterli eşleştirme kodu 10 dakika geçerli ve tek kullanımlıktır.
- Sunucu cihaz anahtarının yalnızca SHA-256 özetini saklar.
- Eklentideki cihaz anahtarı `chrome.storage.local` içinde tutulur ve senkronize
  edilmez.
- Her sağlayıcı yalnızca manifestte izin verilen kendi alan adına erişebilir.
- Resmî API bağlantıları Chrome açıkken sayfadan bağımsız çalışabilir. API'siz
  platformlarda platformun kendi oturumu ve sayfası gerektiği için Play Connect
  özel penceresi açık veya simge durumuna küçültülmüş kalır.
