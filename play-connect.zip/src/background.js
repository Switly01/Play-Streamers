import {
  FEATURED_PROVIDER_IDS,
  PROVIDERS,
  PROVIDER_BY_ID,
  emptyProviderSettings,
  isProviderUrlAllowed
} from "./providers.js";
import { extractJsonCandidates, normalizeCandidate } from "./core.js";

const API_ORIGIN = "https://api.pstreamers.com";
const PAIR_ENDPOINT = `${API_ORIGIN}/api/donate-bridge/pair/claim`;
const DEFAULT_EVENT_ENDPOINT = `${API_ORIGIN}/api/donate-bridge/events`;
const DEVICE_STATUS_ENDPOINT = `${API_ORIGIN}/api/donate-bridge/device/status`;
const DEVICE_DISCONNECT_ENDPOINT = `${API_ORIGIN}/api/donate-bridge/device/disconnect`;
const SUPPORT_ENDPOINT = `${API_ORIGIN}/api/donate-bridge/support`;
const APP_VERSION = `chrome-${chrome.runtime.getManifest().version}`;
const POLL_ALARM = "play-streamers-donate-poll";
const RETRY_ALARM = "play-streamers-donate-retry";
const MAX_QUEUE = 500;
const MAX_SEEN = 10000;
const MAX_LOCAL_LOG = 120;
const OFFSCREEN_PATH = "offscreen/offscreen.html";
const PROVIDER_DEFAULTS_VERSION = 3;
const QUEUE_SANITIZER_VERSION = 5;
const FAST_POLL_INTERVAL_MS = 5 * 1000;
const MAX_PENDING_EVENT_AGE_MS = 90 * 24 * 60 * 60 * 1000;
let streamElementsSocket = null;
let streamElementsConnectPromise = null;
let streamElementsReconnectTimer = 0;
let streamElementsReconnectAttempts = 0;
let flushQueuePromise = null;
let fastPollTimer = 0;
let fastPollRunning = false;
let stateMutationTail = Promise.resolve();

function defaultState() {
  return {
    installationId: crypto.randomUUID(),
    connection: {
      paired: false,
      deviceId: "",
      deviceName: "",
      deviceToken: "",
      apiEndpoint: DEFAULT_EVENT_ENDPOINT,
      providerCatalogVersion: 0,
      pairedAt: 0,
      pairingCode: "",
      lastStatusCheckAt: 0,
      lastDeliveryAttemptAt: 0,
      lastDeliveryAt: 0,
      lastDeliveryHttpStatus: 0,
      lastServerEventCount: 0,
      lastError: ""
    },
    providers: Object.fromEntries(PROVIDERS.map(provider => [
      provider.id,
      emptyProviderSettings(provider)
    ])),
    queue: [],
    seen: {},
    activity: [],
    queueSanitizerVersion: QUEUE_SANITIZER_VERSION
  };
}

function sanitizeQueue(items) {
  const now = Date.now();
  const unique = new Map();
  for (const item of Array.isArray(items) ? items : []) {
    const event = item?.event;
    if (!item?.queueId || !event?.providerId || !event?.eventId) continue;
    const hasEventAt = event.eventAt !== null && event.eventAt !== undefined && event.eventAt !== "";
    const eventAt = hasEventAt ? Number(event.eventAt) : NaN;
    if (hasEventAt && (!Number.isFinite(eventAt) || eventAt < now - MAX_PENDING_EVENT_AGE_MS || eventAt > now + 5 * 60 * 1000)) continue;
    const observedAt = Number(event.observedAt);
    const safeEvent = {
      ...event,
      eventAt: hasEventAt ? Math.trunc(eventAt) : null,
      observedAt: Number.isFinite(observedAt) && observedAt <= now + 5 * 60 * 1000
        ? Math.trunc(observedAt)
        : now
    };
    unique.set(`${safeEvent.providerId}:${safeEvent.eventId}`, { ...item, event: safeEvent });
  }
  return [...unique.values()].slice(-MAX_QUEUE);
}

async function readState() {
  const stored = await chrome.storage.local.get("playStreamersDonate");
  const initial = defaultState();
  const value = stored.playStreamersDonate || {};
  const providers = { ...initial.providers };
  const storedProviderDefaultsVersion = Number(value.providerDefaultsVersion || 0);
  const shouldEnableProviders = storedProviderDefaultsVersion < 1;
  const shouldResetLegacyGitHubStatus = storedProviderDefaultsVersion < 2;
  const shouldMigrateProviderBaselines = storedProviderDefaultsVersion < 3;
  for (const provider of PROVIDERS) {
    providers[provider.id] = {
      ...providers[provider.id],
      ...(value.providers?.[provider.id] || {}),
      selectors: {
        ...providers[provider.id].selectors,
        ...(value.providers?.[provider.id]?.selectors || {})
      }
    };
    if (shouldEnableProviders) providers[provider.id].enabled = true;
    if (shouldResetLegacyGitHubStatus && provider.id === "githubsponsors") {
      providers[provider.id].loginStatus = "unknown";
      providers[provider.id].status = "setup";
      providers[provider.id].lastError = "";
    }
    if (shouldMigrateProviderBaselines && Number(providers[provider.id].lastScanAt || 0) > 0) {
      providers[provider.id].baselineComplete = true;
    }
  }
  const result = {
    ...initial,
    ...value,
    providerDefaultsVersion: PROVIDER_DEFAULTS_VERSION,
    connection: { ...initial.connection, ...(value.connection || {}) },
    providers,
    queue: sanitizeQueue(value.queue),
    seen: value.seen && typeof value.seen === "object" ? value.seen : {},
    activity: Array.isArray(value.activity)
      ? value.activity
        .filter(item => !/Destek zaman[ıi] ge[cç]ersiz/i.test(String(item?.message || "")))
        .slice(0, MAX_LOCAL_LOG)
      : []
  };
  // Older Play Connect builds could keep a workers.dev or retired endpoint in
  // Chrome storage. Delivery always uses the current first-party API address.
  result.connection.apiEndpoint = DEFAULT_EVENT_ENDPOINT;
  if (/Destek zaman[ıi] ge[cç]ersiz/i.test(String(result.connection.lastError || ""))) {
    result.connection.lastError = "";
  }
  const resetLegacyDeliveryBackoff = Number(value.queueSanitizerVersion || 0) < QUEUE_SANITIZER_VERSION;
  if (resetLegacyDeliveryBackoff) {
    result.queue = result.queue.map(item => ({
      ...item,
      attempts: 0,
      nextAttemptAt: 0,
    }));
  }
  const queueNeedsMigration = Number(value.queueSanitizerVersion || 0) < QUEUE_SANITIZER_VERSION
    || result.queue.length !== (Array.isArray(value.queue) ? value.queue.length : 0);
  result.queueSanitizerVersion = QUEUE_SANITIZER_VERSION;
  if (shouldEnableProviders || shouldResetLegacyGitHubStatus || shouldMigrateProviderBaselines || queueNeedsMigration) {
    await chrome.storage.local.set({ playStreamersDonate: result });
  }
  return result;
}

async function writeState(state) {
  await chrome.storage.local.set({ playStreamersDonate: state });
}

function mutateState(mutator) {
  const operation = stateMutationTail.then(async () => {
    const state = await readState();
    const result = await mutator(state);
    await writeState(state);
    return { state, result };
  });
  stateMutationTail = operation.then(() => undefined, () => undefined);
  return operation;
}

function publicState(state) {
  return {
    connection: {
      ...state.connection,
      deviceToken: undefined,
      hasDeviceToken: Boolean(state.connection.deviceToken)
    },
    providers: Object.fromEntries(PROVIDERS.map(provider => {
      const config = state.providers[provider.id] || emptyProviderSettings(provider);
      return [provider.id, {
        ...config,
        apiToken: undefined,
        hasApiToken: Boolean(config.apiToken)
      }];
    })),
    providerCatalog: PROVIDERS,
    featuredProviderIds: FEATURED_PROVIDER_IDS,
    queueCount: state.queue.length,
    activity: state.activity.slice(0, 20)
  };
}

function connectedProviderIds(state) {
  return PROVIDERS.filter(provider => {
    const config = state.providers?.[provider.id];
    if (!config?.enabled || config.status !== "connected") return false;
    return provider.integration !== "session" || config.loginStatus === "observed";
  }).map(provider => provider.id);
}

function activity(state, type, message, providerId = "") {
  state.activity.unshift({
    id: crypto.randomUUID(),
    type,
    message: String(message || "").slice(0, 240),
    providerId,
    at: Date.now()
  });
  state.activity = state.activity.slice(0, MAX_LOCAL_LOG);
}

async function notify(title, message) {
  const state = await readState();
  if (state.notifications === false) return;
  await chrome.notifications.create({
    type: "basic",
    iconUrl: chrome.runtime.getURL("assets/icon-128.png"),
    title,
    message
  }).catch(() => {});
}

function base64ToBytes(value) {
  const binary = atob(String(value || ""));
  return Uint8Array.from(binary, char => char.charCodeAt(0));
}

function supportAttachmentMime(name, suppliedType) {
  const cleanType = String(suppliedType || "").trim().toLowerCase();
  if (cleanType && cleanType !== "application/octet-stream") return cleanType;
  const extension = String(name || "").toLowerCase().split(".").pop();
  return ({
    png: "image/png",
    jpg: "image/jpeg",
    jpeg: "image/jpeg",
    webp: "image/webp",
    gif: "image/gif",
    pdf: "application/pdf",
    txt: "text/plain",
    doc: "application/msword",
    docx: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    xls: "application/vnd.ms-excel",
    xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
  })[extension] || "application/octet-stream";
}

async function sendSupportRequest(input) {
  const state = await readState();
  const paired = Boolean(state.connection.paired && state.connection.deviceToken);
  const email = String(input?.email || "").trim();
  if (!paired && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    throw new Error("Hesap bağlı değilken geçerli bir e-posta adresi girmelisin.");
  }
  const form = new FormData();
  form.append("email", paired ? "" : email);
  form.append("subject", String(input?.subject || "").trim());
  form.append("message", String(input?.message || "").trim());
  for (const item of Array.isArray(input?.attachments) ? input.attachments.slice(0, 10) : []) {
    const bytes = base64ToBytes(item.base64);
    const name = String(item.name || "dosya");
    const file = new Blob([bytes], { type: supportAttachmentMime(name, item.type) });
    form.append("attachments", file, name);
  }
  const headers = { "x-play-streamers-bridge": APP_VERSION };
  if (paired) headers.authorization = `Bearer ${state.connection.deviceToken}`;
  const response = await fetch(SUPPORT_ENDPOINT, { method: "POST", headers, body: form });
  const result = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(result.error || "Destek talebi gönderilemedi.");
  await mutateState(latest => {
    activity(latest, "success", "Play Connect destek talebi gönderildi.");
  });
  return { ...result, accountEmailUsed: paired };
}

function formatPairingCode(value) {
  const normalized = String(value || "").toUpperCase().replace(/[^A-Z0-9]/g, "");
  if (normalized.length === 16) {
    return `${normalized.slice(0, 4)}-${normalized.slice(4, 8)}-${normalized.slice(8, 12)}-${normalized.slice(12)}`;
  }
  if (normalized.length === 12) {
    return `${normalized.slice(0, 4)}-${normalized.slice(4, 8)}-${normalized.slice(8)}`;
  }
  if (normalized.length === 10) {
    return `${normalized.slice(0, 5)}-${normalized.slice(5)}`;
  }
  return normalized;
}

async function pairAccount(code) {
  const state = await readState();
  if (state.connection.paired && state.connection.deviceToken) {
    throw new Error("Yeni kod girmeden önce mevcut Play Streamers bağlantısını kaldır.");
  }
  const normalized = String(code || "").toUpperCase().replace(/[^A-Z0-9]/g, "");
  if (!/^(?:[A-HJ-NP-Z2-9]{10}|[A-HJ-NP-Z2-9]{12}|[A-HJ-NP-Z2-9]{16})$/.test(normalized)) {
    throw new Error("Play Streamers sitesindeki 16 karakterli eşleştirme kodunu gir.");
  }
  const response = await fetch(PAIR_ENDPOINT, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "x-play-streamers-bridge": APP_VERSION
    },
    body: JSON.stringify({
      code: normalized,
      deviceName: "Play Connect",
      clientInstanceId: state.installationId,
      appVersion: APP_VERSION
    })
  });
  const result = await response.json().catch(() => ({}));
  if (!response.ok || !result.deviceToken) {
    throw new Error(result.error || "Eşleştirme tamamlanamadı.");
  }
  const mutation = await mutateState(latest => {
    latest.connection = {
      paired: true,
      deviceId: String(result.device?.id || ""),
      deviceName: String(result.device?.name || "Chrome Eklentisi"),
      deviceToken: String(result.deviceToken),
      apiEndpoint: String(result.apiEndpoint || DEFAULT_EVENT_ENDPOINT),
      providerCatalogVersion: Number(result.providerCatalogVersion || 0),
      pairedAt: Date.now(),
      pairingCode: formatPairingCode(normalized),
      lastStatusCheckAt: Date.now(),
      lastDeliveryAttemptAt: 0,
      lastDeliveryAt: 0,
      lastDeliveryHttpStatus: 0,
      lastServerEventCount: 0,
      lastError: ""
    };
    activity(latest, "success", "Play Streamers hesabı güvenli biçimde eşleştirildi.");
  });
  await flushQueue();
  return publicState(mutation.state);
}

async function clearDisconnectedState(expectedToken, message) {
  const mutation = await mutateState(state => {
    if (expectedToken && state.connection.deviceToken !== expectedToken) return false;
    state.connection = defaultState().connection;
    state.queue = [];
    activity(state, "info", message);
    return true;
  });
  return publicState(mutation.state);
}

async function syncConnectionStatus(force = false) {
  const state = await readState();
  if (!state.connection.paired || !state.connection.deviceToken) return publicState(state);
  const expectedToken = state.connection.deviceToken;
  if (!force && Date.now() - Number(state.connection.lastStatusCheckAt || 0) < 4 * 1000) {
    return publicState(state);
  }
  try {
    const response = await fetch(DEVICE_STATUS_ENDPOINT, {
      method: "POST",
      headers: {
        authorization: `Bearer ${state.connection.deviceToken}`,
        "content-type": "application/json",
        "x-play-streamers-bridge": APP_VERSION
      },
      body: JSON.stringify({ connectedProviders: connectedProviderIds(state) })
    });
    const result = await response.json().catch(() => ({}));
    if (response.status === 401 || response.status === 404 || response.status === 410) {
      return clearDisconnectedState(expectedToken, "Site tarafında kaldırılan hesap eşleştirmesi bu eklentiden de kapatıldı.");
    }
    if (!response.ok || !result.paired) {
      throw new Error(result.error || `Bağlantı durumu alınamadı (${response.status}).`);
    }
    const mutation = await mutateState(latest => {
      if (latest.connection.deviceToken !== expectedToken) return false;
      latest.connection.lastStatusCheckAt = Date.now();
      latest.connection.lastError = "";
      if (result.device?.name) latest.connection.deviceName = String(result.device.name);
      return true;
    });
    return publicState(mutation.state);
  } catch (error) {
    const mutation = await mutateState(latest => {
      if (latest.connection.deviceToken !== expectedToken) return false;
      latest.connection.lastStatusCheckAt = Date.now();
      latest.connection.lastError = String(error?.message || "Bağlantı durumu kontrol edilemedi.").slice(0, 240);
      return true;
    });
    return publicState(mutation.state);
  }
}

function providerLoginLaunchUrl(provider) {
  const url = new URL(provider.loginUrl);
  if (/(?:^|\/)(?:login|signin|sign-in|auth|giris|giriş|oturum)(?:\/|$)/i.test(url.pathname)) {
    return url.toString();
  }
  url.searchParams.set("ps_open_login", "1");
  return url.toString();
}

function providerLogoutLaunchUrl(provider) {
  const url = new URL(provider.logoutUrl || provider.homeUrl);
  url.searchParams.set("ps_open_logout", "1");
  return url.toString();
}

async function disconnectAccount() {
  const state = await readState();
  const expectedToken = state.connection.deviceToken;
  if (state.connection.paired && state.connection.deviceToken) {
    const response = await fetch(DEVICE_DISCONNECT_ENDPOINT, {
      method: "POST",
      headers: {
        authorization: `Bearer ${state.connection.deviceToken}`,
        "content-type": "application/json",
        "x-play-streamers-bridge": APP_VERSION
      },
      body: "{}"
    });
    const result = await response.json().catch(() => ({}));
    if (!response.ok && ![401, 404, 410].includes(response.status)) {
      throw new Error(result.error || "Site bağlantısı kesilemedi. Bağlantını kontrol edip tekrar dene.");
    }
  }
  return clearDisconnectedState(expectedToken, "Hesap eşleştirmesi eklenti ve Play Streamers sitesinde birlikte kaldırıldı.");
}

async function ensureOffscreenDocument() {
  const offscreenUrl = chrome.runtime.getURL(OFFSCREEN_PATH);
  if (chrome.runtime.getContexts) {
    const contexts = await chrome.runtime.getContexts({
      contextTypes: ["OFFSCREEN_DOCUMENT"],
      documentUrls: [offscreenUrl]
    });
    if (contexts.length) return;
  }
  try {
    await chrome.offscreen.createDocument({
      url: OFFSCREEN_PATH,
      reasons: ["DOM_PARSER"],
      justification: "Kullanıcının seçtiği donate geçmişi sayfasını yerel olarak ayrıştırmak."
    });
  } catch (error) {
    if (!String(error?.message || "").includes("single offscreen")) throw error;
  }
}

async function parseHtml(providerId, html, pageUrl, selectors) {
  await ensureOffscreenDocument();
  return chrome.runtime.sendMessage({
    target: "offscreen",
    type: "PARSE_DONATE_HTML",
    providerId,
    html,
    pageUrl,
    selectors
  });
}

async function fetchSessionCandidates(provider, config) {
  const sourceUrl = String(config.historyUrl || config.detectedUrl || "").trim();
  if (!sourceUrl || !isProviderUrlAllowed(provider, sourceUrl)) {
    throw new Error("Önce “Platforma giriş yap” düğmesini kullan ve giriş tamamlandıktan sonra bağlantıyı doğrula.");
  }
  const response = await fetch(sourceUrl, {
    credentials: "include",
    cache: "no-store",
    redirect: "follow",
    headers: {
      accept: "text/html,application/json;q=0.9,*/*;q=0.7"
    }
  });
  if (!response.ok) {
    throw new Error(`Platform ${response.status} yanıtı verdi. Chrome oturumunu kontrol et.`);
  }
  const contentType = String(response.headers.get("content-type") || "").toLowerCase();
  if (contentType.includes("application/json")) {
    return extractJsonCandidates(await response.json());
  }
  const html = await response.text();
  const parsed = await parseHtml(provider.id, html, response.url || sourceUrl, config.selectors);
  if (!parsed?.ok) throw new Error(parsed?.error || "Donate geçmişi sayfası okunamadı.");
  if (parsed.loginRequired) {
    throw new Error("Platform oturumu bulunamadı. Platforma Chrome üzerinden bir kez giriş yap.");
  }
  return parsed.candidates || [];
}

async function fetchStreamlabsCandidates(config) {
  if (!config.apiToken) {
    throw new Error("Streamlabs kişisel erişim anahtarını eklenti ayarlarına ekle.");
  }
  const response = await fetch("https://streamlabs.com/api/v2.0/donations?limit=100", {
    cache: "no-store",
    headers: {
      accept: "application/json",
      authorization: `Bearer ${config.apiToken}`
    }
  });
  const result = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(result.message || result.error || "Streamlabs verileri alınamadı.");
  }
  return extractJsonCandidates(result);
}

async function fetchTipeeeStreamCandidates(config) {
  if (!config.apiToken) {
    throw new Error("TipeeeStream hesabındaki API anahtarını ekle.");
  }
  const endpoint = new URL("https://api.tipeeestream.com/v1.0/events.json");
  endpoint.searchParams.set("apiKey", config.apiToken);
  endpoint.searchParams.append("type[]", "donation");
  endpoint.searchParams.set("limit", "100");
  endpoint.searchParams.set("sort", "createdAt");
  endpoint.searchParams.set("order", "desc");
  const response = await fetch(endpoint, {
    cache: "no-store",
    headers: { accept: "application/json" }
  });
  const result = await response.json().catch(() => ({}));
  if (!response.ok || String(result.message || "").toLowerCase() === "error") {
    throw new Error(result.message || "TipeeeStream verileri alınamadı.");
  }
  return (Array.isArray(result.events) ? result.events : [])
    .filter(item => String(item?.type || "").toLowerCase() === "donation")
    .map(item => {
      const parameters = item?.parameters || {};
      return {
        eventId: String(item?.id || item?.ref || ""),
        name: String(parameters.username || "İsimsiz destekçi"),
        amount: parameters.amount ?? item?.["parameters.amount"] ?? "",
        currency: String(parameters.currency || ""),
        message: String(parameters.message || parameters.formattedMessage || ""),
        time: item?.created_at || item?.inserted_at || "",
        rawText: JSON.stringify(item)
      };
    });
}

async function fetchDonationAlertsCandidates(config) {
  if (!config.apiToken) {
    throw new Error("DonationAlerts resmî erişim anahtarını ekle.");
  }
  const response = await fetch("https://www.donationalerts.com/api/v1/alerts/donations", {
    cache: "no-store",
    headers: {
      accept: "application/json",
      authorization: `Bearer ${config.apiToken}`
    }
  });
  const result = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(result.message || result.error || "DonationAlerts verileri alınamadı.");
  }
  return (Array.isArray(result.data) ? result.data : []).map(item => ({
    eventId: String(item?.id || ""),
    name: String(item?.username || "İsimsiz destekçi"),
    amount: item?.amount,
    currency: String(item?.currency || ""),
    message: String(item?.message || ""),
    time: item?.created_at || "",
    rawText: JSON.stringify(item)
  }));
}

function streamElementsCandidate(message) {
  const data = message?.data || {};
  const donation = data.donation || {};
  if (String(data.approved || "").toLowerCase() === "rejected") return null;
  return {
    eventId: String(data._id || data.transactionId || message.id || ""),
    name: String(donation.user?.username || donation.user?.name || "İsimsiz destekçi"),
    amount: donation.amount,
    currency: String(donation.currency || ""),
    message: String(donation.message || ""),
    time: data.createdAt || message.ts || "",
    rawText: JSON.stringify(data)
  };
}

function closeStreamElementsSocket() {
  clearTimeout(streamElementsReconnectTimer);
  streamElementsReconnectTimer = 0;
  streamElementsReconnectAttempts = 0;
  const socket = streamElementsSocket;
  streamElementsSocket = null;
  streamElementsConnectPromise = null;
  if (socket && socket.readyState < WebSocket.CLOSING) socket.close(1000, "configuration changed");
}

function scheduleStreamElementsReconnect() {
  clearTimeout(streamElementsReconnectTimer);
  const delay = Math.min(60_000, 1000 * (2 ** streamElementsReconnectAttempts));
  streamElementsReconnectAttempts += 1;
  streamElementsReconnectTimer = setTimeout(async () => {
    const state = await readState();
    const config = state.providers.streamelements;
    if (!config?.enabled || !config.apiToken || !config.channelId) return;
    connectStreamElements(config).catch(() => {});
  }, delay);
}

async function connectStreamElements(config) {
  if (!config.apiToken || !config.channelId) {
    throw new Error("StreamElements JWT anahtarını ve kanal kimliğini ekle.");
  }
  if (streamElementsSocket?.readyState === WebSocket.OPEN && streamElementsSocket.playStreamersReady) {
    return { connected: true };
  }
  if (streamElementsConnectPromise) return streamElementsConnectPromise;
  streamElementsConnectPromise = new Promise((resolve, reject) => {
    let settled = false;
    const nonce = crypto.randomUUID();
    const socket = new WebSocket("wss://astro.streamelements.com/");
    streamElementsSocket = socket;
    const timeout = setTimeout(() => {
      if (!settled) {
        settled = true;
        reject(new Error("StreamElements bağlantısı zaman aşımına uğradı."));
      }
      socket.close();
    }, 12_000);

    const complete = (error = null) => {
      if (settled) return;
      settled = true;
      clearTimeout(timeout);
      if (error) reject(error);
      else resolve({ connected: true });
    };

    socket.addEventListener("message", event => {
      let message;
      try { message = JSON.parse(event.data); } catch { return; }
      if (message.type === "welcome") {
        socket.send(JSON.stringify({
          type: "subscribe",
          nonce,
          data: {
            topic: "channel.tips",
            room: config.channelId,
            token: config.apiToken,
            token_type: "jwt"
          }
        }));
        return;
      }
      if (message.type === "response" && message.nonce === nonce) {
        if (message.error) {
          complete(new Error(message.data?.message || `StreamElements bağlantısı reddedildi: ${message.error}`));
        } else {
          socket.playStreamersReady = true;
          streamElementsReconnectAttempts = 0;
          complete();
        }
        return;
      }
      if (message.type === "message" && message.topic === "channel.tips") {
        const candidate = streamElementsCandidate(message);
        if (candidate) {
          const provider = PROVIDER_BY_ID.get("streamelements");
          acceptCandidates(provider, [candidate], "StreamElements canlı").catch(() => {});
        }
        return;
      }
      if (message.type === "reconnect") {
        socket.close(1012, "server reconnect");
      }
    });
    socket.addEventListener("error", () => {
      complete(new Error("StreamElements WebSocket bağlantısı kurulamadı."));
    });
    socket.addEventListener("close", () => {
      clearTimeout(timeout);
      if (streamElementsSocket === socket) streamElementsSocket = null;
      streamElementsConnectPromise = null;
      if (!settled) complete(new Error("StreamElements bağlantısı kapandı."));
      scheduleStreamElementsReconnect();
    });
  });
  return streamElementsConnectPromise;
}

async function fetchStreamElementsCandidates(config) {
  await connectStreamElements(config);
  return [];
}

async function providerCandidates(provider, config) {
  if (provider.integration === "streamlabs-api") return fetchStreamlabsCandidates(config);
  if (provider.integration === "streamelements-api") return fetchStreamElementsCandidates(config);
  if (provider.integration === "tipeeestream-api") return fetchTipeeeStreamCandidates(config);
  if (provider.integration === "donationalerts-api") return fetchDonationAlertsCandidates(config);
  return fetchSessionCandidates(provider, config);
}

function pruneSeen(seen) {
  const entries = Object.entries(seen).sort((a, b) => Number(b[1]) - Number(a[1]));
  return Object.fromEntries(entries.slice(0, MAX_SEEN));
}

async function acceptCandidates(provider, candidates, sourceLabel = "background") {
  const sorted = Array.isArray(candidates) ? candidates.slice(-150) : [];
  const mutation = await mutateState(async state => {
    const config = state.providers[provider.id] || emptyProviderSettings(provider);
    const realtimeSource = /canlı|websocket/i.test(String(sourceLabel || ""));
    const establishBaseline = !config.baselineComplete && !realtimeSource;
    let accepted = 0;
    for (const candidate of sorted) {
      const event = await normalizeCandidate(provider, candidate);
      if (!event) continue;
      const key = `${provider.id}:${event.eventId}`;
      if (state.seen[key]) continue;
      state.seen[key] = Date.now();
      if (establishBaseline) continue;
      state.queue.push({
        queueId: crypto.randomUUID(),
        event,
        attempts: 0,
        nextAttemptAt: 0,
        queuedAt: Date.now()
      });
      accepted += 1;
    }
    state.seen = pruneSeen(state.seen);
    state.queue = state.queue.slice(-MAX_QUEUE);
    if (establishBaseline) {
      config.baselineComplete = true;
      config.lastScanAt = Date.now();
      state.providers[provider.id] = config;
      activity(state, "info", `${provider.name}: mevcut hareketler başlangıç noktası olarak kaydedildi; bundan sonra yalnızca yeni donate olayları alınacak.`, provider.id);
    }
    if (accepted) {
      config.lastEventAt = Date.now();
      config.lastEventName = `${accepted} yeni donate`;
      activity(state, "success", `${provider.name}: ${accepted} yeni donate bulundu (${sourceLabel}).`, provider.id);
    }
    return accepted;
  });
  const accepted = mutation.result;
  if (accepted) {
    const delivery = await flushQueue();
    const deliveryText = Number(delivery?.delivered || 0) > 0
      ? `${accepted} yeni hareket Play Streamers hesabına gönderildi.`
      : `${accepted} yeni hareket güvenli teslimat kuyruğuna alındı.`;
    await notify("Yeni donate bulundu", `${provider.name}: ${deliveryText}`);
  }
  return accepted;
}

async function scanProvider(providerId, manual = false) {
  const provider = PROVIDER_BY_ID.get(providerId);
  if (!provider) throw new Error("Platform bulunamadı.");
  const state = await readState();
  const config = state.providers[providerId];
  if (!config?.enabled && !manual) return { skipped: true };
  try {
    const candidates = await providerCandidates(provider, config);
    const accepted = await acceptCandidates(provider, candidates, manual ? "test" : "arka plan");
    await mutateState(latest => {
      latest.providers[providerId].status = "connected";
      latest.providers[providerId].lastError = "";
      latest.providers[providerId].lastScanAt = Date.now();
      if (!accepted && manual) {
        activity(latest, "info", `${provider.name}: bağlantı başarılı, yeni donate bulunamadı.`, provider.id);
      }
    });
    return { ok: true, accepted, candidateCount: candidates.length };
  } catch (error) {
    await mutateState(latest => {
      latest.providers[providerId].status = "error";
      latest.providers[providerId].lastError = String(error?.message || "Bağlantı hatası").slice(0, 240);
      latest.providers[providerId].lastScanAt = Date.now();
      activity(latest, "error", `${provider.name}: ${latest.providers[providerId].lastError}`, provider.id);
    });
    throw error;
  }
}

async function scanAll() {
  const state = await readState();
  for (const provider of PROVIDERS) {
    const config = state.providers[provider.id];
    if (!config?.enabled) continue;
    const ready = provider.integration === "session"
      ? config.loginStatus === "observed" && Boolean(config.historyUrl || config.detectedUrl)
      : Boolean(config.apiToken) && (provider.id !== "streamelements" || Boolean(config.channelId));
    if (!ready) continue;
    await scanProvider(provider.id).catch(() => {});
  }
}

async function postQueuedItem(item, connection) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 15 * 1000);
  try {
    const response = await fetch(connection.apiEndpoint || DEFAULT_EVENT_ENDPOINT, {
      method: "POST",
      cache: "no-store",
      signal: controller.signal,
      headers: {
        accept: "application/json",
        authorization: `Bearer ${connection.deviceToken}`,
        "content-type": "application/json",
        "x-play-streamers-bridge": APP_VERSION
      },
      body: JSON.stringify({ event: item.event })
    });
    const result = await response.json().catch(() => ({}));
    if (!response.ok || result?.ok !== true || result?.accepted !== true) {
      const error = new Error(result.error || `Play Streamers sunucusu teslimatı onaylamadı (${response.status}).`);
      error.status = response.status || 502;
      throw error;
    }
    return { ...result, httpStatus: response.status };
  } catch (error) {
    if (error?.name === "AbortError") {
      const timeoutError = new Error("Play Streamers sunucusu 15 saniye içinde yanıt vermedi.");
      timeoutError.status = 0;
      throw timeoutError;
    }
    throw error;
  } finally {
    clearTimeout(timeout);
  }
}

async function flushQueueInternal() {
  const snapshot = await readState();
  if (!snapshot.connection.paired || !snapshot.connection.deviceToken || !snapshot.queue.length) {
    return { delivered: 0, remaining: snapshot.queue.length };
  }
  const now = Date.now();
  const deliveredIds = new Set();
  const retryUpdates = new Map();
  let delivered = 0;
  let discarded = 0;
  let disconnected = false;
  let lastError = "";
  let lastServerEventCount = null;
  let attempted = 0;
  let lastDeliveryHttpStatus = 0;
  for (const item of snapshot.queue) {
    if (item.nextAttemptAt && item.nextAttemptAt > now) {
      continue;
    }
    attempted += 1;
    try {
      const receipt = await postQueuedItem(item, snapshot.connection);
      lastDeliveryHttpStatus = Number(receipt.httpStatus || 200);
      deliveredIds.add(item.queueId);
      delivered += 1;
      if (Number.isFinite(Number(receipt.deviceEventCount))) {
        lastServerEventCount = Math.max(Number(lastServerEventCount || 0), Number(receipt.deviceEventCount));
      }
    } catch (error) {
      const attempts = Number(item.attempts || 0) + 1;
      const status = Number(error.status || 0);
      lastDeliveryHttpStatus = status;
      lastError = String(error?.message || "Teslimat hatası").slice(0, 240);
      if ([401, 404, 410].includes(status)) {
        disconnected = true;
        break;
      }
      retryUpdates.set(item.queueId, {
        ...item,
        attempts,
        nextAttemptAt: Date.now() + Math.min(5 * 60 * 1000, (2 ** Math.min(attempts, 7)) * 5 * 1000)
      });
    }
  }
  const mutation = await mutateState(latest => {
    if (disconnected && latest.connection.deviceToken === snapshot.connection.deviceToken) {
      latest.connection = defaultState().connection;
      latest.queue = [];
      activity(latest, "info", "Site tarafında kaldırılan hesap eşleştirmesi eklentiden de kapatıldı.");
    } else {
      latest.queue = latest.queue
        .filter(item => !deliveredIds.has(item.queueId))
        .map(item => retryUpdates.get(item.queueId) || item)
        .slice(-MAX_QUEUE);
      if (attempted) {
        latest.connection.lastDeliveryAttemptAt = Date.now();
        latest.connection.lastDeliveryHttpStatus = lastDeliveryHttpStatus;
      }
      if (delivered) {
        latest.connection.lastDeliveryAt = Date.now();
        if (lastServerEventCount !== null) {
          latest.connection.lastServerEventCount = lastServerEventCount;
        }
        latest.connection.lastError = "";
        activity(latest, "success", `${delivered} donate olayı Play Streamers'a gönderildi ve sunucu tarafından doğrulandı.`);
      } else if (lastError) {
        latest.connection.lastError = lastError;
        activity(latest, "error", `Donate teslimatı bekliyor: ${lastError}`);
      }
    }
  });
  return { delivered, discarded, remaining: mutation.state.queue.length, disconnected };
}

async function flushQueue() {
  if (flushQueuePromise) return flushQueuePromise;
  flushQueuePromise = flushQueueInternal().finally(() => {
    flushQueuePromise = null;
  });
  return flushQueuePromise;
}

async function saveProvider(providerId, nextInput) {
  const provider = PROVIDER_BY_ID.get(providerId);
  if (!provider) throw new Error("Platform bulunamadı.");
  const historyUrl = String(nextInput.historyUrl || "").trim();
  if (historyUrl && !isProviderUrlAllowed(provider, historyUrl)) {
    throw new Error(`${provider.name} için yalnızca kendi alan adındaki bir adres kullanılabilir.`);
  }
  const mutation = await mutateState(state => {
    const previous = state.providers[providerId] || emptyProviderSettings(provider);
    state.providers[providerId] = {
      ...previous,
      enabled: Boolean(nextInput.enabled),
      historyUrl,
      apiToken: String(nextInput.apiToken || "").trim() || previous.apiToken || "",
      channelId: String(nextInput.channelId || "").trim(),
      defaultCurrency: /^[A-Z]{3}$/.test(String(nextInput.defaultCurrency || "").toUpperCase())
        ? String(nextInput.defaultCurrency).toUpperCase()
        : provider.defaultCurrency,
      selectors: {
        item: String(nextInput.selectors?.item || "").trim(),
        eventId: String(nextInput.selectors?.eventId || "").trim(),
        name: String(nextInput.selectors?.name || "").trim(),
        amount: String(nextInput.selectors?.amount || "").trim(),
        currency: String(nextInput.selectors?.currency || "").trim(),
        message: String(nextInput.selectors?.message || "").trim(),
        time: String(nextInput.selectors?.time || "").trim()
      },
      status: nextInput.enabled ? previous.status : "setup",
      lastError: nextInput.enabled ? previous.lastError : ""
    };
    if (nextInput.clearApiToken) state.providers[providerId].apiToken = "";
    activity(state, "info", `${provider.name} ayarları kaydedildi.`, providerId);
  });
  if (providerId === "streamelements") closeStreamElementsSocket();
  return publicState(mutation.state);
}

async function configureAlarms() {
  await chrome.alarms.create(POLL_ALARM, { periodInMinutes: 0.5 });
  await chrome.alarms.create(RETRY_ALARM, { periodInMinutes: 0.5 });
}

function startFastPolling() {
  clearInterval(fastPollTimer);
  const runFastCycle = async () => {
    if (fastPollRunning) return;
    fastPollRunning = true;
    try {
      await syncConnectionStatus();
      await scanAll();
      await flushQueue();
    } catch (_) {
      // The alarm fallback retries transient browser/network failures.
    } finally {
      fastPollRunning = false;
    }
  };
  runFastCycle().catch(() => {});
  fastPollTimer = setInterval(runFastCycle, FAST_POLL_INTERVAL_MS);
}

chrome.runtime.onInstalled.addListener(() => {
  configureAlarms().catch(() => {});
  startFastPolling();
  scanAll().catch(() => {});
  flushQueue().catch(() => {});
});

chrome.runtime.onStartup.addListener(() => {
  configureAlarms().catch(() => {});
  startFastPolling();
  syncConnectionStatus(true).catch(() => {});
  scanAll().catch(() => {});
  flushQueue().catch(() => {});
});

chrome.alarms.onAlarm.addListener(alarm => {
  if (alarm.name === POLL_ALARM) {
    (async () => {
      await syncConnectionStatus();
      await scanAll();
      await flushQueue();
    })().catch(() => {});
  }
  if (alarm.name === RETRY_ALARM) flushQueue().catch(() => {});
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.target === "offscreen") return false;
  (async () => {
    switch (message?.type) {
      case "GET_STATE":
        return syncConnectionStatus();
      case "PAIR_ACCOUNT":
        return pairAccount(message.code);
      case "DISCONNECT_ACCOUNT":
        return disconnectAccount();
      case "SAVE_PROVIDER":
        return saveProvider(message.providerId, message.config || {});
      case "TEST_PROVIDER":
        return scanProvider(message.providerId, true);
      case "POLL_NOW":
        await scanAll();
        await flushQueue();
        return publicState(await readState());
      case "SEND_SUPPORT":
        return sendSupportRequest(message.payload || {});
      case "OPEN_PROVIDER_LOGIN": {
        const provider = PROVIDER_BY_ID.get(message.providerId);
        if (!provider) throw new Error("Platform bulunamadı.");
        await mutateState(state => {
          state.providers[provider.id].loginStatus = "waiting";
          state.providers[provider.id].lastError = "";
          activity(state, "info", `${provider.name} giriş sayfası kullanıcı isteğiyle açıldı.`, provider.id);
        });
        await chrome.tabs.create({ url: providerLoginLaunchUrl(provider) });
        return { ok: true };
      }
      case "OPEN_PROVIDER_LOGOUT": {
        const provider = PROVIDER_BY_ID.get(message.providerId);
        if (!provider) throw new Error("Platform bulunamadı.");
        const mutation = await mutateState(state => {
          const config = state.providers[provider.id] || emptyProviderSettings(provider);
          config.loginStatus = "logout-pending";
          config.lastError = "";
          if (provider.integration === "session") config.status = "setup";
          state.providers[provider.id] = config;
          activity(state, "info", `${provider.name} çıkış sayfası kullanıcı isteğiyle açıldı.`, provider.id);
        });
        await chrome.tabs.create({ url: providerLogoutLaunchUrl(provider) });
        return publicState(mutation.state);
      }
      case "PAGE_STATUS": {
        const provider = PROVIDER_BY_ID.get(message.providerId);
        if (!provider || !sender?.url || !isProviderUrlAllowed(provider, sender.url)) {
          return { ok: false, ignored: true };
        }
        const mutation = await mutateState(state => {
          const config = state.providers[provider.id] || emptyProviderSettings(provider);
          const wasWaitingForLogin = config.loginStatus === "waiting";
          const explicitlyAuthenticated = message.authenticated === true;
          const explicitlyLoggedOut = message.authenticated === false || message.loginRequired === true;
          let loginStatus = config.loginStatus || "unknown";
          if (explicitlyLoggedOut) {
            loginStatus = "required";
          } else if (config.loginStatus !== "logout-pending"
            && (explicitlyAuthenticated || (wasWaitingForLogin && (message.accountLike || message.historyLike)))) {
            loginStatus = "observed";
          }
          const observedUrl = String(sender.url || "").slice(0, 1800);
          config.loginStatus = loginStatus;
          config.lastPageAt = Date.now();
          if (loginStatus === "observed" && (message.accountLike || message.historyLike || wasWaitingForLogin)) {
            config.detectedUrl = observedUrl;
          }
          if (loginStatus === "observed" && message.historyLike && !config.historyUrl) {
            config.historyUrl = observedUrl;
          }
          if (loginStatus === "observed") {
            config.lastError = "";
            if (config.status === "setup") config.status = "ready";
          } else if (loginStatus === "required") {
            config.status = "setup";
          }
          state.providers[provider.id] = config;
          return {
            loginStatus,
            detectedUrl: config.detectedUrl,
            historyUrlDetected: Boolean(message.historyLike)
          };
        });
        return {
          ok: true,
          ...mutation.result
        };
      }
      case "PAGE_CANDIDATES": {
        const provider = PROVIDER_BY_ID.get(message.providerId);
        if (!provider || !sender?.url || !isProviderUrlAllowed(provider, sender.url)) {
          return { ok: false, ignored: true };
        }
        const state = await readState();
        if (!state.providers[provider.id]?.enabled) return { ok: false, ignored: true };
        const accepted = await acceptCandidates(provider, message.candidates || [], "açık sayfa");
        const observedUrl = String(sender.url || "").slice(0, 1800);
        await mutateState(latest => {
          if (observedUrl && isProviderUrlAllowed(provider, observedUrl)) {
            latest.providers[provider.id].detectedUrl = observedUrl;
            latest.providers[provider.id].historyUrl = observedUrl;
          }
          latest.providers[provider.id].loginStatus = "observed";
          latest.providers[provider.id].status = "connected";
          latest.providers[provider.id].lastError = "";
          latest.providers[provider.id].lastScanAt = Date.now();
        });
        return { ok: true, accepted };
      }
      default:
        return { ok: false, error: "Bilinmeyen eklenti isteği." };
    }
  })()
    .then(result => sendResponse({ ok: true, result }))
    .catch(error => sendResponse({ ok: false, error: String(error?.message || "İşlem tamamlanamadı.") }));
  return true;
});

configureAlarms().catch(() => {});
startFastPolling();
scanAll().catch(() => {});
flushQueue().catch(() => {});
readState().then(state => {
  const config = state.providers.streamelements;
  if (config?.enabled && config.apiToken && config.channelId) connectStreamElements(config).catch(() => {});
}).catch(() => {});
