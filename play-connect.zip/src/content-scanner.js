(() => {
  "use strict";
  const MAX_CANDIDATES = 80;
  const MAX_JSON_SCRIPT_BYTES = 1_000_000;
  const AMOUNT_PATTERN = /(?:₺|TL|TRY|\$|USD|€|EUR|£|GBP)\s*[\d.,]+|[\d.,]+\s*(?:₺|TL|TRY|\$|USD|€|EUR|£|GBP)/i;
  const JSON_KEYS = {
    id: ["eventId", "event_id", "donationId", "donation_id", "transactionId", "transaction_id", "_id", "id"],
    name: ["donorName", "donor_name", "displayName", "display_name", "username", "sender", "from", "name"],
    amount: ["amount", "amountFormatted", "amount_formatted", "total", "gross", "value"],
    currency: ["currency", "currencyCode", "currency_code"],
    message: ["message", "comment", "note", "text", "description"],
    time: ["createdAt", "created_at", "timestamp", "eventAt", "event_at", "date", "time"]
  };
  let lastFingerprint = "";
  let lastStatusFingerprint = "";
  let timer = 0;
  let loginUiRequested = false;
  let logoutUiRequested = false;
  let accountMenuRequested = false;

  function text(node, maximum = 1000) {
    return String(node?.textContent || "")
      .replace(/\s+/g, " ")
      .trim()
      .slice(0, maximum);
  }

  function pick(root, selector, maximum) {
    if (!selector) return "";
    try {
      const node = root.querySelector(selector);
      return text(node, maximum);
    } catch {
      return "";
    }
  }

  function genericRows() {
    const selectors = [
      "[data-donation-id]",
      "[data-transaction-id]",
      "[data-tip-id]",
      "[data-payment-id]",
      "[data-order-id]",
      ".donation",
      ".donate",
      ".tip",
      ".transaction",
      ".payment",
      "[class*='donation' i]",
      "[class*='donate' i]",
      "[class*='transaction' i]",
      "[class*='payment' i]",
      "[class*='support' i]",
      "table tbody tr",
      "[role='row']",
      ".history-item",
      ".list-group-item"
    ];
    const nodes = [];
    for (const selector of selectors) {
      try {
        for (const node of document.querySelectorAll(selector)) {
          if (!nodes.includes(node)) nodes.push(node);
          if (nodes.length >= MAX_CANDIDATES) return nodes;
        }
      } catch {}
    }
    return nodes;
  }

  function firstJsonValue(object, keys) {
    for (const key of keys) {
      if (object?.[key] !== undefined && object?.[key] !== null && object[key] !== "") return object[key];
    }
    return "";
  }

  function jsonCandidate(object) {
    if (!object || typeof object !== "object" || Array.isArray(object)) return null;
    const amount = firstJsonValue(object, JSON_KEYS.amount);
    const eventId = firstJsonValue(object, JSON_KEYS.id);
    const name = firstJsonValue(object, JSON_KEYS.name);
    const message = firstJsonValue(object, JSON_KEYS.message);
    if (amount === "" || (!eventId && !name && !message)) return null;
    return {
      eventId: String(eventId || "").slice(0, 320),
      name: String(name || "").slice(0, 160),
      amount,
      currency: String(firstJsonValue(object, JSON_KEYS.currency) || "").slice(0, 16),
      message: String(message || "").slice(0, 1000),
      time: firstJsonValue(object, JSON_KEYS.time),
      rawText: JSON.stringify(object).slice(0, 3000)
    };
  }

  function candidatesFromJsonScripts() {
    const results = [];
    const scripts = [...document.querySelectorAll("script[type='application/json'],script#__NEXT_DATA__")].slice(0, 12);
    for (const script of scripts) {
      const raw = String(script.textContent || "");
      if (!raw || raw.length > MAX_JSON_SCRIPT_BYTES) continue;
      let payload;
      try { payload = JSON.parse(raw); } catch { continue; }
      const queue = [payload];
      const visited = new Set();
      while (queue.length && results.length < MAX_CANDIDATES) {
        const current = queue.shift();
        if (!current || typeof current !== "object" || visited.has(current)) continue;
        visited.add(current);
        const candidate = jsonCandidate(current);
        if (candidate) results.push(candidate);
        for (const value of Array.isArray(current) ? current : Object.values(current)) {
          if (value && typeof value === "object") queue.push(value);
        }
      }
      if (results.length >= MAX_CANDIDATES) break;
    }
    return results;
  }

  function candidatesFromRows(rows, config) {
    const selectors = config?.selectors || {};
    return rows.map((row, index) => {
      const rawText = text(row, 3000);
      if (!AMOUNT_PATTERN.test(rawText)) return null;
      const amountMatch = rawText.match(AMOUNT_PATTERN)?.[0] || "";
      return {
        eventId: pick(row, selectors.eventId, 320)
          || row.getAttribute("data-donation-id")
          || row.getAttribute("data-transaction-id")
          || row.getAttribute("data-tip-id")
          || "",
        name: pick(row, selectors.name, 160)
          || pick(row, "[data-donor],.donor,.username,.sender,.name", 160),
        amount: pick(row, selectors.amount, 120)
          || pick(row, "[data-amount],.amount,.total,.value", 120)
          || amountMatch,
        currency: pick(row, selectors.currency, 12),
        message: pick(row, selectors.message, 1000)
          || pick(row, "[data-message],.message,.comment,.note,.description", 1000),
        time: pick(row, selectors.time, 100)
          || row.querySelector("time")?.getAttribute("datetime")
          || "",
        rawText,
        rowIndex: index
      };
    }).filter(Boolean);
  }

  function visiblePasswordInput() {
    return [...document.querySelectorAll("input[type='password']")].some(input => {
      const style = getComputedStyle(input);
      const bounds = input.getBoundingClientRect();
      return style.display !== "none" && style.visibility !== "hidden" && bounds.width > 0 && bounds.height > 0;
    });
  }

  function visibleAction(pattern) {
    return [...document.querySelectorAll("a,button,[role='button'],summary,input[type='submit']")].some(node => {
      const style = getComputedStyle(node);
      const bounds = node.getBoundingClientRect();
      if (style.display === "none" || style.visibility === "hidden" || bounds.width <= 0 || bounds.height <= 0) return false;
      const copy = normalizeActionText([
        node.textContent,
        node.getAttribute("value"),
        node.getAttribute("aria-label"),
        node.getAttribute("title"),
        node.getAttribute("href")
      ].filter(Boolean).join(" "));
      return pattern.test(copy);
    });
  }

  function pageStatus(provider = null) {
    const path = `${location.pathname}${location.hash}`.toLowerCase();
    const loginPath = /(?:^|\/)(?:login|signin|sign-in|auth|giris|giriş|oturum)(?:\/|$|\?|#)/i.test(path);
    const visibleLogin = visibleAction(/(?:^|\b)(giriş|giris|üye girişi|oturum aç|sign in|log in|login)(?:\b|$)/i);
    const visibleLogout = visibleAction(/(?:^|\b)(çıkış|cikis|oturumu kapat|hesaptan çık|sign out|log out|logout)(?:\b|$)/i);
    let authenticated = null;
    let loginRequired = loginPath || visiblePasswordInput();
    if (provider?.id === "githubsponsors") {
      const githubLogin = String(
        document.querySelector('meta[name="user-login"]')?.getAttribute("content")
        || document.querySelector('meta[name="octolytics-actor-login"]')?.getAttribute("content")
        || ""
      ).trim();
      const githubAccountMenu = Boolean(document.querySelector(
        '[aria-label*="profile and more" i],[data-login]:not([data-login=""]),meta[name="user-login"][content]:not([content=""])'
      ));
      authenticated = Boolean(githubLogin || githubAccountMenu);
      loginRequired = loginRequired || !authenticated;
    } else if (loginRequired || (visibleLogin && !visibleLogout)) {
      authenticated = false;
      loginRequired = true;
    } else if (visibleLogout) {
      authenticated = true;
    }
    const historyLike = /donat|donation|tip|support|payment|transaction|history|gecmis|geçmiş|destek|bagis|bağış|income|revenue|alert/i.test(path);
    const accountLike = historyLike || /dashboard|panel|account|profile|manage|creator|streamer|member/i.test(path);
    return { loginRequired, historyLike, accountLike, authenticated };
  }

  function normalizeActionText(value) {
    return String(value || "").replace(/\s+/g, " ").trim().toLocaleLowerCase("tr-TR");
  }

  function openRequestedLoginUi() {
    if (loginUiRequested) return;
    const url = new URL(location.href);
    if (url.searchParams.get("ps_open_login") !== "1") return;
    if (pageStatus().loginRequired) {
      loginUiRequested = true;
      url.searchParams.delete("ps_open_login");
      history.replaceState(history.state, "", `${url.pathname}${url.search}${url.hash}`);
      return;
    }
    const candidates = [...document.querySelectorAll([
      "a[href*='login' i]",
      "a[href*='signin' i]",
      "a[href*='sign-in' i]",
      "a[href*='giris' i]",
      "a[href*='oturum' i]",
      "a[href*='account/login' i]",
      "a[href*='uye-girisi' i]",
      "button",
      "[role='button']",
      "input[type='submit']"
    ].join(","))].filter(node => {
      const style = getComputedStyle(node);
      const bounds = node.getBoundingClientRect();
      if (style.display === "none" || style.visibility === "hidden" || bounds.width <= 0 || bounds.height <= 0) return false;
      const copy = normalizeActionText([
        node.textContent,
        node.getAttribute("value"),
        node.getAttribute("aria-label"),
        node.getAttribute("title"),
        node.getAttribute("href")
      ].filter(Boolean).join(" "));
      return /(?:^|\b)(giriş|giris|üye girişi|oturum aç|hesabına giriş|sign in|log in|login)(?:\b|$)/i.test(copy);
    });
    if (candidates[0]) {
      const loginAction = candidates[0];
      const directHref = loginAction.closest("a[href]")?.href
        || (loginAction.matches("a[href]") ? loginAction.href : "");
      loginUiRequested = true;
      url.searchParams.delete("ps_open_login");
      history.replaceState(history.state, "", `${url.pathname}${url.search}${url.hash}`);
      if (/^https?:\/\//i.test(String(directHref || "")) && directHref !== location.href) {
        location.assign(directHref);
      } else {
        loginAction.click();
      }
    }
  }

  function openRequestedLogoutUi() {
    if (logoutUiRequested) return;
    const url = new URL(location.href);
    if (url.searchParams.get("ps_open_logout") !== "1") return;
    const logoutPattern = /(?:^|\b)(çıkış|cikis|oturumu kapat|hesaptan çık|sign out|log out|logout)(?:\b|$)/i;
    const candidates = [...document.querySelectorAll([
      "a[href*='logout' i]",
      "a[href*='signout' i]",
      "a[href*='sign-out' i]",
      "a[href*='cikis' i]",
      "form[action*='logout' i] button",
      "form[action*='logout' i] input[type='submit']",
      "button",
      "[role='button']"
    ].join(","))].filter(node => {
      const style = getComputedStyle(node);
      const bounds = node.getBoundingClientRect();
      if (style.display === "none" || style.visibility === "hidden" || bounds.width <= 0 || bounds.height <= 0) return false;
      const copy = normalizeActionText([
        node.textContent,
        node.getAttribute("value"),
        node.getAttribute("aria-label"),
        node.getAttribute("title"),
        node.getAttribute("href"),
        node.closest("form")?.getAttribute("action")
      ].filter(Boolean).join(" "));
      return logoutPattern.test(copy);
    });
    if (candidates[0]) {
      logoutUiRequested = true;
      url.searchParams.delete("ps_open_logout");
      history.replaceState(history.state, "", `${url.pathname}${url.search}${url.hash}`);
      candidates[0].click();
      return;
    }
    if (!accountMenuRequested) {
      const accountMenu = document.querySelector([
        '[aria-label*="account" i]',
        '[aria-label*="profile" i]',
        '[aria-label*="hesap" i]',
        '[aria-label*="profil" i]',
        '[data-testid*="account" i]',
        '[data-testid*="profile" i]'
      ].join(","));
      if (accountMenu) {
        accountMenuRequested = true;
        accountMenu.click();
        window.setTimeout(() => {
          accountMenuRequested = false;
          schedule();
        }, 450);
      }
    }
  }

  async function scan() {
    const response = await chrome.runtime.sendMessage({ type: "GET_STATE" }).catch(() => null);
    if (!response?.ok) return;
    const state = response.result;
    const provider = state.providerCatalog?.find(item => (
      item.domains || []
    ).some(domain => location.hostname === domain || location.hostname.endsWith(`.${domain}`)));
    if (!provider) return;
    const config = state.providers?.[provider.id];
    const status = pageStatus(provider);
    const statusFingerprint = `${provider.id}:${location.href}:${status.loginRequired}:${status.historyLike}:${status.accountLike}:${status.authenticated}`;
    if (statusFingerprint !== lastStatusFingerprint) {
      lastStatusFingerprint = statusFingerprint;
      await chrome.runtime.sendMessage({
        type: "PAGE_STATUS",
        providerId: provider.id,
        ...status
      }).catch(() => {});
    }
    if (!config?.enabled || provider.integration !== "session") return;
    let rows = [];
    if (config.selectors?.item) {
      try { rows = [...document.querySelectorAll(config.selectors.item)].slice(0, MAX_CANDIDATES); } catch {}
    }
    if (!rows.length) rows = genericRows();
    const candidates = [...candidatesFromRows(rows, config), ...candidatesFromJsonScripts()]
      .slice(0, MAX_CANDIDATES);
    if (!candidates.length) return;
    const fingerprint = candidates.map(item => item.eventId || item.rawText).join("\u001e").slice(0, 12000);
    if (fingerprint === lastFingerprint) return;
    lastFingerprint = fingerprint;
    await chrome.runtime.sendMessage({
      type: "PAGE_CANDIDATES",
      providerId: provider.id,
      candidates
    }).catch(() => {});
  }

  function schedule() {
    clearTimeout(timer);
    timer = setTimeout(() => {
      openRequestedLoginUi();
      openRequestedLogoutUi();
      scan().catch(() => {});
    }, 250);
  }

  window.setTimeout(openRequestedLoginUi, 350);
  window.setTimeout(openRequestedLoginUi, 1200);
  schedule();
  const observer = new MutationObserver(schedule);
  observer.observe(document.documentElement, {
    childList: true,
    subtree: true,
    characterData: true,
    attributes: true,
    attributeFilter: ["class", "data-state", "data-status", "aria-live"]
  });
  window.addEventListener("pageshow", schedule);
  window.setInterval(schedule, 1500);
})();
