export const FEATURED_PROVIDER_IDS = [
  "bynogame",
  "klasgame",
  "streamlabs",
  "streamelements"
];

function provider(definition) {
  return {
    region: "Türkiye",
    integration: "session",
    connectionMode: "login",
    apiLabel: "",
    apiTokenLabel: "",
    apiHelpUrl: "",
    channelIdLabel: "",
    brandColor: "#53fc18",
    ...definition,
    icon: `assets/providers/${definition.id}.png`
  };
}

export const PROVIDERS = [
  provider({
    id: "bynogame",
    name: "ByNoGame",
    homeUrl: "https://donate.bynogame.com/",
    loginUrl: "https://www.bynogame.com/tr/login",
    domains: ["bynogame.com"],
    defaultCurrency: "TRY",
    brandColor: "#ff8a00"
  }),
  provider({
    id: "klasgame",
    name: "Klasgame",
    homeUrl: "https://www.klasgame.com/",
    loginUrl: "https://www.klasgame.com/giris-yap/?refresh=1",
    domains: ["klasgame.com"],
    defaultCurrency: "TRY",
    brandColor: "#f1c232"
  }),
  provider({
    id: "streamlabs",
    name: "Streamlabs",
    region: "Global",
    integration: "streamlabs-api",
    connectionMode: "login-api",
    homeUrl: "https://streamlabs.com/dashboard",
    loginUrl: "https://streamlabs.com/login",
    domains: ["streamlabs.com"],
    defaultCurrency: "USD",
    apiLabel: "Donation API",
    apiTokenLabel: "Streamlabs erişim anahtarı",
    apiHelpUrl: "https://dev.streamlabs.com/reference/donations",
    brandColor: "#80f5d2"
  }),
  provider({
    id: "streamelements",
    name: "StreamElements",
    region: "Global",
    integration: "streamelements-api",
    connectionMode: "login-api",
    homeUrl: "https://streamelements.com/dashboard",
    loginUrl: "https://streamelements.com/dashboard",
    domains: ["streamelements.com"],
    defaultCurrency: "USD",
    apiLabel: "Canlı tip bağlantısı",
    apiTokenLabel: "StreamElements JWT anahtarı",
    apiHelpUrl: "https://docs.streamelements.com/websockets/topics/channel-tips",
    channelIdLabel: "StreamElements kanal kimliği",
    brandColor: "#5bc4ff"
  }),
  provider({
    id: "pindirim",
    name: "Pindirim",
    homeUrl: "https://www.pindirim.com/",
    loginUrl: "https://www.pindirim.com/giris",
    domains: ["pindirim.com"],
    defaultCurrency: "TRY",
    brandColor: "#7c5cff"
  }),
  provider({
    id: "gamesatis",
    name: "GameSatış",
    homeUrl: "https://www.gamesatis.com/donate",
    loginUrl: "https://www.gamesatis.com/giris-yap",
    domains: ["gamesatis.com"],
    defaultCurrency: "TRY",
    brandColor: "#ff5e2b"
  }),
  provider({
    id: "oyunfor",
    name: "Oyunfor",
    homeUrl: "https://www.oyunfor.com/donate",
    loginUrl: "https://www.oyunfor.com/giris",
    domains: ["oyunfor.com"],
    defaultCurrency: "TRY",
    brandColor: "#ff9c00"
  }),
  provider({
    id: "itemsatis",
    name: "İtemSatış",
    homeUrl: "https://www.itemsatis.com/",
    loginUrl: "https://www.itemsatis.com/",
    domains: ["itemsatis.com"],
    defaultCurrency: "TRY",
    brandColor: "#ff3e61"
  }),
  provider({
    id: "oyuneks",
    name: "Oyuneks",
    homeUrl: "https://oyuneks.com/",
    loginUrl: "https://oyuneks.com/giris-yap",
    domains: ["oyuneks.com"],
    defaultCurrency: "TRY",
    brandColor: "#fa3f47"
  }),
  provider({
    id: "hesap",
    name: "Hesap.com.tr",
    homeUrl: "https://hesap.com.tr/yayincilar",
    loginUrl: "https://hesap.com.tr/login",
    domains: ["hesap.com.tr"],
    defaultCurrency: "TRY",
    brandColor: "#1aa7ff"
  }),
  provider({
    id: "dijipin",
    name: "Dijipin",
    homeUrl: "https://www.dijipin.com/yayincilar",
    loginUrl: "https://www.dijipin.com/",
    domains: ["dijipin.com"],
    defaultCurrency: "TRY",
    brandColor: "#ffbd00"
  }),
  provider({
    id: "epin",
    name: "EPİN",
    homeUrl: "https://epin.com.tr/",
    loginUrl: "https://epin.com.tr/",
    domains: ["epin.com.tr"],
    defaultCurrency: "TRY",
    brandColor: "#ff384c"
  }),
  provider({
    id: "inovapin",
    name: "İnovapin",
    homeUrl: "https://www.inovapin.com/yayinci/inovapin",
    loginUrl: "https://www.inovapin.com/",
    domains: ["inovapin.com"],
    defaultCurrency: "TRY",
    brandColor: "#8ce63f"
  }),
  provider({
    id: "kofi",
    name: "Ko-fi",
    region: "Global",
    homeUrl: "https://ko-fi.com/manage",
    loginUrl: "https://ko-fi.com/account/login",
    domains: ["ko-fi.com"],
    defaultCurrency: "USD",
    brandColor: "#ff5e5b"
  }),
  provider({
    id: "buymeacoffee",
    name: "Buy Me a Coffee",
    region: "Global",
    homeUrl: "https://www.buymeacoffee.com/dashboard",
    loginUrl: "https://www.buymeacoffee.com/login",
    domains: ["buymeacoffee.com"],
    defaultCurrency: "USD",
    brandColor: "#ffdd00"
  }),
  provider({
    id: "patreon",
    name: "Patreon",
    region: "Global",
    homeUrl: "https://www.patreon.com/creator-home",
    loginUrl: "https://www.patreon.com/login",
    domains: ["patreon.com"],
    defaultCurrency: "USD",
    brandColor: "#ff424d"
  }),
  provider({
    id: "fourthwall",
    name: "Fourthwall",
    region: "Global",
    homeUrl: "https://fourthwall.com/dashboard",
    loginUrl: "https://fourthwall.com/login",
    domains: ["fourthwall.com"],
    defaultCurrency: "USD",
    brandColor: "#8e63ff"
  }),
  provider({
    id: "tipeeestream",
    name: "TipeeeStream",
    region: "Global",
    integration: "tipeeestream-api",
    connectionMode: "login-api",
    homeUrl: "https://www.tipeeestream.com/dashboard",
    loginUrl: "https://www.tipeeestream.com/login",
    domains: ["tipeeestream.com"],
    defaultCurrency: "EUR",
    apiLabel: "Events API",
    apiTokenLabel: "TipeeeStream API anahtarı",
    apiHelpUrl: "https://api.tipeeestream.com/api-doc/events",
    brandColor: "#20cfcf"
  }),
  provider({
    id: "donationalerts",
    name: "DonationAlerts",
    region: "Global",
    integration: "donationalerts-api",
    connectionMode: "login-api",
    homeUrl: "https://www.donationalerts.com/dashboard",
    loginUrl: "https://www.donationalerts.com/login",
    domains: ["donationalerts.com"],
    defaultCurrency: "USD",
    apiLabel: "Donations API",
    apiTokenLabel: "DonationAlerts erişim anahtarı",
    apiHelpUrl: "https://www.donationalerts.com/apidoc",
    brandColor: "#f57520"
  }),
  provider({
    id: "pally",
    name: "Pally.gg",
    region: "Global",
    homeUrl: "https://pally.gg/dashboard",
    loginUrl: "https://pally.gg/login",
    domains: ["pally.gg"],
    defaultCurrency: "USD",
    brandColor: "#6c72ff"
  }),
  provider({
    id: "streamloots",
    name: "Streamloots",
    region: "Global",
    homeUrl: "https://www.streamloots.com/",
    loginUrl: "https://www.streamloots.com/sign-in",
    domains: ["streamloots.com"],
    defaultCurrency: "USD",
    brandColor: "#9147ff"
  }),
  provider({
    id: "destream",
    name: "DeStream",
    region: "Global",
    homeUrl: "https://destream.net/",
    loginUrl: "https://destream.net/login",
    domains: ["destream.net"],
    defaultCurrency: "USD",
    brandColor: "#ff4b55"
  }),
  provider({
    id: "throne",
    name: "Throne",
    region: "Global",
    homeUrl: "https://throne.com/",
    loginUrl: "https://throne.com/login",
    domains: ["throne.com"],
    defaultCurrency: "USD",
    brandColor: "#f76aa6"
  }),
  provider({
    id: "boosty",
    name: "Boosty",
    region: "Global",
    homeUrl: "https://boosty.to/",
    loginUrl: "https://boosty.to/app/auth",
    domains: ["boosty.to"],
    defaultCurrency: "USD",
    brandColor: "#f15f2c"
  }),
  provider({
    id: "tiltify",
    name: "Tiltify",
    region: "Global",
    homeUrl: "https://tiltify.com/",
    loginUrl: "https://app.tiltify.com/login",
    domains: ["tiltify.com"],
    defaultCurrency: "USD",
    brandColor: "#674ea7"
  }),
  provider({
    id: "liberapay",
    name: "Liberapay",
    region: "Global",
    homeUrl: "https://liberapay.com/",
    loginUrl: "https://liberapay.com/log-in",
    domains: ["liberapay.com"],
    defaultCurrency: "EUR",
    brandColor: "#f6c915"
  }),
  provider({
    id: "tipeee",
    name: "Tipeee",
    region: "Global",
    homeUrl: "https://www.tipeee.com/",
    loginUrl: "https://www.tipeee.com/login",
    domains: ["tipeee.com"],
    defaultCurrency: "EUR",
    brandColor: "#ef5a5a"
  }),
  provider({
    id: "itemsultan",
    name: "ItemSultan",
    homeUrl: "https://www.itemsultan.com/",
    loginUrl: "https://www.itemsultan.com/giris.html",
    domains: ["itemsultan.com"],
    defaultCurrency: "TRY",
    brandColor: "#f5b72e"
  }),
  provider({
    id: "paypal",
    name: "PayPal",
    region: "Global",
    homeUrl: "https://www.paypal.com/myaccount/",
    loginUrl: "https://www.paypal.com/signin",
    domains: ["paypal.com"],
    defaultCurrency: "USD",
    brandColor: "#0070e0"
  }),
  provider({
    id: "gumroad",
    name: "Gumroad",
    region: "Global",
    homeUrl: "https://gumroad.com/dashboard",
    loginUrl: "https://gumroad.com/login",
    domains: ["gumroad.com"],
    defaultCurrency: "USD",
    brandColor: "#ff90e8"
  }),
  provider({
    id: "githubsponsors",
    name: "GitHub Sponsors",
    region: "Global",
    homeUrl: "https://github.com/sponsors",
    loginUrl: "https://github.com/login",
    logoutUrl: "https://github.com/logout",
    domains: ["github.com"],
    defaultCurrency: "USD",
    brandColor: "#f0f6fc"
  }),
  provider({
    id: "givebutter",
    name: "Givebutter",
    region: "Global",
    homeUrl: "https://givebutter.com/dashboard",
    loginUrl: "https://givebutter.com/login",
    domains: ["givebutter.com"],
    defaultCurrency: "USD",
    brandColor: "#ffcc00"
  }),
  provider({
    id: "donorbox",
    name: "Donorbox",
    region: "Global",
    homeUrl: "https://donorbox.org/orgs",
    loginUrl: "https://donorbox.org/login",
    domains: ["donorbox.org"],
    defaultCurrency: "USD",
    brandColor: "#2e79ff"
  })
];

export const PROVIDER_BY_ID = new Map(PROVIDERS.map(item => [item.id, item]));

export function providerForUrl(rawUrl) {
  let hostname = "";
  try {
    hostname = new URL(rawUrl).hostname.toLowerCase();
  } catch {
    return null;
  }
  return PROVIDERS.find(item => item.domains.some(domain => (
    hostname === domain || hostname.endsWith(`.${domain}`)
  ))) || null;
}

export function isProviderUrlAllowed(item, rawUrl) {
  try {
    const hostname = new URL(rawUrl).hostname.toLowerCase();
    return item.domains.some(domain => hostname === domain || hostname.endsWith(`.${domain}`));
  } catch {
    return false;
  }
}

export function emptyProviderSettings(item) {
  return {
    enabled: true,
    historyUrl: "",
    detectedUrl: "",
    loginStatus: "unknown",
    lastPageAt: 0,
    apiToken: "",
    channelId: "",
    selectors: {
      item: "",
      eventId: "",
      name: "",
      amount: "",
      currency: "",
      message: "",
      time: ""
    },
    status: "setup",
    lastError: "",
    lastScanAt: 0,
    lastEventAt: 0,
    lastEventName: "",
    baselineComplete: false,
    defaultCurrency: item.defaultCurrency
  };
}
