import test from "node:test";
import assert from "node:assert/strict";

test("API'siz platform ayrı gizli pencerede açılır ve izleme sayfası otomatik bağlanır", async () => {
  const originalSetInterval = globalThis.setInterval;
  const originalClearInterval = globalThis.clearInterval;
  globalThis.setInterval = () => 0;
  globalThis.clearInterval = () => {};

  let messageListener = null;
  let stored = {};
  const updatedTabs = [];
  globalThis.chrome = {
    runtime: {
      getManifest: () => ({ version: "1.0.0" }),
      getURL: path => `chrome-extension://aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/${path}`,
      onInstalled: { addListener() {} },
      onStartup: { addListener() {} },
      onMessage: { addListener(listener) { messageListener = listener; } },
      sendMessage: async () => ({ ok: true })
    },
    extension: {
      async isAllowedIncognitoAccess() { return true; }
    },
    storage: {
      local: {
        async get() { return structuredClone(stored); },
        async set(value) { stored = { ...stored, ...structuredClone(value) }; }
      }
    },
    alarms: {
      async create() {},
      onAlarm: { addListener() {} }
    },
    notifications: { async create() {} },
    windows: {
      async create(input) {
        assert.equal(input.incognito, true);
        assert.equal(input.type, "popup");
        return { id: 9, incognito: true, tabs: [{ id: 41, windowId: 9, incognito: true, url: input.url }] };
      },
      async get() { throw new Error("Pencere henüz yok"); },
      async update() {},
      onRemoved: { addListener() {} }
    },
    tabs: {
      async create() { throw new Error("İlk özel pencere doğrudan windows.create ile açılmalı."); },
      async update(tabId, input) {
        updatedTabs.push({ tabId, ...input });
        return { id: tabId, windowId: 9, incognito: true, ...input };
      },
      async sendMessage() { return { ok: true, candidateCount: 0, loginStatus: "observed" }; },
      async reload() {},
      onRemoved: { addListener() {} }
    },
    offscreen: { async createDocument() {} }
  };

  await import(`../src/background.js?managed-browser=${Date.now()}`);
  assert.equal(typeof messageListener, "function");
  const send = (message, sender = {}) => new Promise((resolve, reject) => {
    const timeout = setTimeout(() => reject(new Error("Eklenti mesajı zaman aşımına uğradı.")), 2000);
    messageListener(message, sender, response => {
      clearTimeout(timeout);
      resolve(response);
    });
  });

  const opened = await send({ type: "OPEN_PROVIDER_LOGIN", providerId: "bynogame" });
  assert.equal(opened.ok, true);
  assert.equal(opened.result.managedBrowser.windowId, 9);
  assert.equal(opened.result.providers.bynogame.managedTabId, 41);
  assert.equal(opened.result.providers.bynogame.captureMode, "managed-private");

  const managedSender = {
    url: "https://www.bynogame.com/tr/account",
    tab: { id: 41, windowId: 9, incognito: true }
  };
  const status = await send({
    type: "PAGE_STATUS",
    providerId: "bynogame",
    authenticated: true,
    loginRequired: false,
    strongLoginRequired: false,
    accountLike: true,
    historyLike: false
  }, managedSender);
  assert.equal(status.ok, true);
  assert.equal(status.result.loginStatus, "observed");

  const discovery = await send({
    type: "PAGE_MONITOR_DISCOVERY",
    providerId: "bynogame",
    url: "https://donate.bynogame.com/history",
    confidence: 12
  }, { ...managedSender, url: "https://donate.bynogame.com/" });
  assert.equal(discovery.ok, true);
  assert.equal(stored.playStreamersDonate.providers.bynogame.historyUrl, "https://donate.bynogame.com/history");
  assert.ok(updatedTabs.some(item => item.tabId === 41 && item.url === "https://donate.bynogame.com/history"));

  const rejectedNormalWindow = await send({
    type: "PAGE_CANDIDATES",
    providerId: "bynogame",
    candidates: []
  }, { url: "https://donate.bynogame.com/history", tab: { id: 5, windowId: 2, incognito: false } });
  assert.equal(rejectedNormalWindow.ok, true);
  assert.equal(rejectedNormalWindow.result.reason, "managed-private-window-required");

  globalThis.setInterval = originalSetInterval;
  globalThis.clearInterval = originalClearInterval;
});
