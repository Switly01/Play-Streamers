import test from "node:test";
import assert from "node:assert/strict";

test("API'siz platform geçici giriş penceresinde açılır ve sekmesiz bağlantı öğrenilir", async () => {
  const originalSetInterval = globalThis.setInterval;
  const originalClearInterval = globalThis.clearInterval;
  const originalFetch = globalThis.fetch;
  globalThis.setInterval = () => 0;
  globalThis.clearInterval = () => {};

  let messageListener = null;
  let stored = {};
  const updatedTabs = [];
  const removedTabs = [];
  globalThis.fetch = async url => {
    const response = new Response(JSON.stringify({ data: [] }), {
      status: 200,
      headers: { "content-type": "application/json" }
    });
    Object.defineProperty(response, "url", { value: String(url) });
    return response;
  };
  globalThis.chrome = {
    runtime: {
      getManifest: () => ({ version: "1.0.0" }),
      getURL: path => `chrome-extension://aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/${path}`,
      onInstalled: { addListener() {} },
      onStartup: { addListener() {} },
      onMessage: { addListener(listener) { messageListener = listener; } },
      sendMessage: async () => ({ ok: true })
    },
    storage: {
      local: {
        async get() { return structuredClone(stored); },
        async set(value) { stored = { ...stored, ...structuredClone(value) }; }
      }
    },
    alarms: {
      async create() {},
      onAlarm: { addListener() {} }
    },
    notifications: { async create() {} },
    windows: {
      async create(input) {
        assert.equal(input.incognito, false);
        assert.equal(input.type, "popup");
        return { id: 9, incognito: false, tabs: [{ id: 41, windowId: 9, incognito: false, url: input.url }] };
      },
      async get() { throw new Error("Pencere henüz yok"); },
      async update() {},
      onRemoved: { addListener() {} }
    },
    tabs: {
      async create() { throw new Error("İlk özel pencere doğrudan windows.create ile açılmalı."); },
      async update(tabId, input) {
        updatedTabs.push({ tabId, ...input });
        return { id: tabId, windowId: 9, incognito: false, ...input };
      },
      async remove(tabId) { removedTabs.push(tabId); },
      async sendMessage() { return { ok: true, candidateCount: 0, loginStatus: "observed" }; },
      async reload() {},
      onRemoved: { addListener() {} }
    },
    offscreen: { async createDocument() {} }
  };

  await import(`../src/background.js?managed-browser=${Date.now()}`);
  assert.equal(typeof messageListener, "function");
  const send = (message, sender = {}) => new Promise((resolve, reject) => {
    const timeout = setTimeout(() => reject(new Error("Eklenti mesajı zaman aşımına uğradı.")), 2000);
    messageListener(message, sender, response => {
      clearTimeout(timeout);
      resolve(response);
    });
  });

  const opened = await send({ type: "OPEN_PROVIDER_LOGIN", providerId: "bynogame" });
  assert.equal(opened.ok, true);
  assert.equal(opened.result.managedBrowser.windowId, 9);
  assert.equal(opened.result.providers.bynogame.managedTabId, 41);
  assert.equal(opened.result.providers.bynogame.captureMode, "login-learning");
  assert.equal(opened.result.providers.bynogame.backgroundStatus, "learning");

  const managedSender = {
    url: "https://www.bynogame.com/tr/account",
    tab: { id: 41, windowId: 9, incognito: false }
  };
  const status = await send({
    type: "PAGE_STATUS",
    providerId: "bynogame",
    authenticated: true,
    loginRequired: false,
    strongLoginRequired: false,
    accountLike: true,
    historyLike: false
  }, managedSender);
  assert.equal(status.ok, true);
  assert.equal(status.result.loginStatus, "observed");

  const discovery = await send({
    type: "PAGE_MONITOR_DISCOVERY",
    providerId: "bynogame",
    url: "https://donate.bynogame.com/history",
    confidence: 12
  }, { ...managedSender, url: "https://donate.bynogame.com/" });
  assert.equal(discovery.ok, true);
  assert.equal(stored.playStreamersDonate.providers.bynogame.historyUrl, "https://donate.bynogame.com/history");
  assert.ok(updatedTabs.some(item => item.tabId === 41 && item.url === "https://donate.bynogame.com/history"));

  const rejectedOtherTab = await send({
    type: "PAGE_CANDIDATES",
    providerId: "bynogame",
    candidates: []
  }, { url: "https://donate.bynogame.com/history", tab: { id: 5, windowId: 2, incognito: false } });
  assert.equal(rejectedOtherTab.ok, true);
  assert.equal(rejectedOtherTab.result.reason, "login-learning-window-required");

  const learned = await send({
    type: "NETWORK_CANDIDATES",
    sourceUrl: "https://donate.bynogame.com/api/donations?page=1",
    method: "GET",
    candidates: []
  }, { ...managedSender, url: "https://donate.bynogame.com/history" });
  assert.equal(learned.ok, true);
  assert.equal(learned.result.feedRemembered, true);
  assert.equal(learned.result.backgroundVerified, true);
  assert.equal(stored.playStreamersDonate.providers.bynogame.captureMode, "background-request");
  assert.equal(stored.playStreamersDonate.providers.bynogame.backgroundStatus, "active");
  assert.equal(stored.playStreamersDonate.providers.bynogame.managedTabId, 0);
  assert.deepEqual(removedTabs, [41]);

  globalThis.setInterval = originalSetInterval;
  globalThis.clearInterval = originalClearInterval;
  globalThis.fetch = originalFetch;
});
