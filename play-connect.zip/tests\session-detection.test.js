import test from "node:test";
import assert from "node:assert/strict";

test("ByNoGame oturumu HttpOnly uyumlu Chrome çerezinden yerelde algılanır", async () => {
  const originalSetInterval = globalThis.setInterval;
  const originalClearInterval = globalThis.clearInterval;
  const originalFetch = globalThis.fetch;
  globalThis.setInterval = () => 0;
  globalThis.clearInterval = () => {};

  const token = "T".repeat(64);
  let authCookies = [{
    name: "auth",
    value: encodeURIComponent(JSON.stringify({ token })),
    domain: ".bynogame.com"
  }];
  let messageListener = null;
  let stored = {
    playStreamersDonate: {
      providers: {
        bynogame: {
          captureMode: "managed-private",
          managedWindowId: 9,
          managedTabId: 41
        }
      },
      providerDefaultsVersion: 4,
      queueSanitizerVersion: 6,
      deliveredLedgerVersion: 1
    }
  };
  globalThis.chrome = {
    runtime: {
      getManifest: () => ({ version: "1.0.0" }),
      getURL: path => `chrome-extension://aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/${path}`,
      onInstalled: { addListener() {} },
      onStartup: { addListener() {} },
      onMessage: { addListener(listener) { messageListener = listener; } },
      sendMessage: async () => ({ ok: true })
    },
    extension: {
      async isAllowedIncognitoAccess() { return true; }
    },
    storage: {
      local: {
        async get() { return structuredClone(stored); },
        async set(value) { stored = { ...stored, ...structuredClone(value) }; }
      }
    },
    cookies: {
      async getAllCookieStores() {
        return [{ id: "1", tabIds: [41] }];
      },
      async getAll(query) {
        assert.equal(query.storeId, "1");
        return structuredClone(authCookies);
      }
    },
    alarms: {
      async create() {},
      onAlarm: { addListener() {} }
    },
    notifications: { async create() {} },
    tabs: { async create() {} },
    offscreen: { async createDocument() {} }
  };

  globalThis.fetch = async url => {
    if (String(url).startsWith("https://api.bynogame.com/streamer/donate/outgoing")) {
      return new Response(JSON.stringify({ data: { data: [] } }), {
        status: 200,
        headers: { "content-type": "application/json" }
      });
    }
    return new Response("", { status: 404 });
  };

  await import(`../src/background.js?session-detection=${Date.now()}`);
  assert.equal(typeof messageListener, "function");
  const response = await new Promise((resolve, reject) => {
    const timeout = setTimeout(() => reject(new Error("Eklenti mesajı zaman aşımına uğradı.")), 2000);
    messageListener({ type: "GET_STATE" }, {}, value => {
      clearTimeout(timeout);
      resolve(value);
    });
  });

  assert.equal(response.ok, true);
  assert.equal(response.result.providers.bynogame.loginStatus, "observed");
  assert.equal(response.result.providers.bynogame.hasSessionToken, true);
  assert.equal(stored.playStreamersDonate.providers.bynogame.sessionToken, token);

  authCookies = [];
  const loggedOut = await new Promise((resolve, reject) => {
    const timeout = setTimeout(() => reject(new Error("Eklenti çıkış mesajı zaman aşımına uğradı.")), 2000);
    messageListener({ type: "GET_STATE" }, {}, value => {
      clearTimeout(timeout);
      resolve(value);
    });
  });
  assert.equal(loggedOut.ok, true);
  assert.equal(loggedOut.result.providers.bynogame.loginStatus, "required");
  assert.equal(loggedOut.result.providers.bynogame.hasSessionToken, false);

  globalThis.fetch = originalFetch;
  globalThis.setInterval = originalSetInterval;
  globalThis.clearInterval = originalClearInterval;
});
