import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";

const read = relativePath => readFile(new URL(relativePath, import.meta.url), "utf8");

test("manual page detection controls are removed", async () => {
  const options = await read("../options/options.js");
  const background = await read("../src/background.js");
  const scanner = await read("../src/content-scanner.js");

  assert.doesNotMatch(options, /Gelişmiş bağlantı ve sayfa algılama/);
  assert.doesNotMatch(options, /name="historyUrl"/);
  assert.doesNotMatch(options, /selector_/);
  assert.match(background, /automatic-network-only/);
  assert.match(scanner, /automaticNetworkOnly:\s*true/);
  assert.match(background, /streamer\/donate\/incoming/);
});

test("OBS alert bağlantısı ve teslimat kuyruğu manifestte etkin", async () => {
  const manifest = JSON.parse(await read("../manifest.json"));
  const background = await read("../src/background.js");

  assert.equal(manifest.incognito, undefined);
  assert.ok(manifest.permissions.includes("tabs"));
  assert.ok(manifest.permissions.includes("webRequest"));
  assert.doesNotMatch(background, /incognito:\s*true/);
  assert.doesNotMatch(background, /OPEN_INCOGNITO_SETTINGS/);
  assert.match(background, /captureMode\s*=\s*"alert-frame"/);
  assert.match(background, /SYNC_ALERT_SOURCES/);
  assert.match(background, /IFRAME_SCRIPTING/);
  assert.doesNotMatch(background, /AUDIO_PLAYBACK/);
  assert.match(await read("../offscreen/offscreen.js"), /frame\.allow\s*=\s*["']autoplay 'none'["']/);
  assert.match(background, /FAST_POLL_INTERVAL_MS\s*=\s*1\s*\*\s*1000/);
  assert.match(background, /state\.queue\.push/);
  assert.match(background, /result\?\.accepted\s*!==\s*true/);
  assert.match(background, /latest\.seen\[eventKey\]/);
  const networkBridge = await read("../src/network-bridge.js");
  assert.match(networkBridge, /PlayConnectWebSocket/);
  assert.match(networkBridge, /function silenceAlertFrameAudio/);
  assert.match(networkBridge, /playConnectSilentPlay/);
  assert.match(background, /OBS alert kartı/);
});

test("OBS bağlantısını kaldırma işlemi tasarımlı onay penceresi kullanır", async () => {
  const options = await read("../options/options.js");
  const html = await read("../options/options.html");
  assert.match(options, /askObsDisconnectConfirmation\(provider\.name\)/);
  assert.doesNotMatch(options, /confirm\("Bu platform için bu Chrome profilinde saklanan OBS bağlantısı/);
  assert.match(html, /id="obsDisconnectModal"/);
  assert.match(html, /id="obsDisconnectConfirm"/);
});

test("yeniden yüklenen eklentinin eski sayfa kodu geçersiz bağlam hatası üretmez", async () => {
  const scanner = await read("../src/content-scanner.js");
  const manifest = JSON.parse(await read("../manifest.json"));
  assert.match(scanner, /function extensionContextAvailable/);
  assert.match(scanner, /function safeRuntimeMessage/);
  assert.match(scanner, /extension-context-invalidated/);
  assert.match(scanner, /extension context invalidated/i);
  assert.match(scanner, /chrome\.runtime\.lastError/);
  assert.equal((scanner.match(/chrome\.runtime\.sendMessage/g) || []).length, 1);
  assert.ok(!manifest.host_permissions.some(value => value.includes("github.com")));
  assert.ok(manifest.host_permissions.includes("https://*.livepix.gg/*"));
  assert.ok(manifest.host_permissions.includes("https://*.toon.at/*"));
  for (const script of manifest.content_scripts) {
    assert.equal(script.all_frames, true);
    assert.ok(script.matches.includes("https://*.livepix.gg/*"));
    assert.ok(script.matches.includes("https://*.toon.at/*"));
    assert.ok(!script.matches.some(value => value.includes("github.com")));
  }
});

test("eşleştirme kodu, D1 olayı ve Dashboard Donate kartı aynı kullanıcı zincirinde", async () => {
  const worker = await read("../../cloudflare-worker.js");
  const site = [
    await read("../../index.html"),
    await read("../../app.js"),
    await read("../../app-final.js")
  ].join("\n");

  assert.match(worker, /pairing\.user_id/);
  assert.match(worker, /\/api\/donate-bridge\/events/);
  assert.match(worker, /authenticateDonateBridgeDevice/);
  assert.match(worker, /UNIQUE\(user_id, provider_id, provider_event_id\)/);
  assert.match(worker, /accepted:\s*true/);
  assert.match(site, /\/api\/donate-bridge\/events\?after=/);
  assert.match(site, /PlayStreamers\.addEvent/);
  assert.match(site, /type:\s*['"]donation['"]/);
  assert.match(site, /data-card=['"]donations['"]|listCard\(['"]donations['"]/);
});
