import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";

const read = relativePath => readFile(new URL(relativePath, import.meta.url), "utf8");

test("özel platform oturumu ve teslimat kuyruğu manifestte etkin", async () => {
  const manifest = JSON.parse(await read("../manifest.json"));
  const background = await read("../src/background.js");

  assert.equal(manifest.incognito, "spanning");
  assert.ok(manifest.permissions.includes("tabs"));
  assert.match(background, /incognito:\s*true/);
  assert.match(background, /managedSenderAllowed/);
  assert.match(background, /state\.queue\.push/);
  assert.match(background, /result\?\.accepted\s*!==\s*true/);
  assert.match(background, /latest\.seen\[eventKey\]/);
  assert.match(await read("../src/network-bridge.js"), /PlayConnectWebSocket/);
});

test("yeniden yüklenen eklentinin eski sayfa kodu geçersiz bağlam hatası üretmez", async () => {
  const scanner = await read("../src/content-scanner.js");
  const manifest = JSON.parse(await read("../manifest.json"));
  assert.match(scanner, /function extensionContextAvailable/);
  assert.match(scanner, /function safeRuntimeMessage/);
  assert.match(scanner, /extension-context-invalidated/);
  assert.match(scanner, /extension context invalidated/i);
  assert.match(scanner, /location\.hostname === "github\.com"/);
  assert.match(scanner, /chrome\.runtime\.lastError/);
  assert.equal((scanner.match(/chrome\.runtime\.sendMessage/g) || []).length, 1);
  assert.ok(manifest.host_permissions.includes("https://*.github.com/*"));
  for (const script of manifest.content_scripts) {
    assert.ok(script.matches.includes("https://github.com/sponsors/*"));
    assert.ok(!script.matches.includes("https://*.github.com/*"));
  }
});

test("eşleştirme kodu, D1 olayı ve Dashboard Donate kartı aynı kullanıcı zincirinde", async () => {
  const worker = await read("../../cloudflare-worker.js");
  const site = await read("../../index.html");

  assert.match(worker, /pairing\.user_id/);
  assert.match(worker, /\/api\/donate-bridge\/events/);
  assert.match(worker, /authenticateDonateBridgeDevice/);
  assert.match(worker, /UNIQUE\(user_id, provider_id, provider_event_id\)/);
  assert.match(worker, /accepted:\s*true/);
  assert.match(site, /\/api\/donate-bridge\/events\?after=/);
  assert.match(site, /PlayStreamers\.addEvent/);
  assert.match(site, /type:\s*['"]donation['"]/);
  assert.match(site, /data-card=['"]donations['"]|listCard\(['"]donations['"]/);
});
